import { useState, useCallback, useMemo } from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  BarChart,
  Bar,
} from 'recharts';

// ═══════════════════════════════════════════════════════
// DATA TABLES
// ═══════════════════════════════════════════════════════
const CP: any = {
  Water: 4.187,
  'Steam (condensing)': 2.01,
  Air: 1.005,
  'Crude Oil': 2.1,
  Benzene: 1.72,
  Ethanol: 2.44,
  Glycol: 2.39,
  Ammonia: 4.7,
  Hydrogen: 14.3,
  'Natural Gas': 2.23,
  Methanol: 2.51,
  Toluene: 1.69,
  Diesel: 2.0,
  Naphtha: 2.2,
  Kerosene: 2.09,
  'Lube Oil': 2.1,
  'Amine (MEA)': 3.93,
  'Caustic Soda': 3.93,
};
const MU: any = {
  Water: 0.001,
  'Steam (condensing)': 0.000013,
  Air: 0.0000185,
  'Crude Oil': 0.025,
  Benzene: 0.00065,
  Ethanol: 0.0012,
  Glycol: 0.021,
  Ammonia: 0.00015,
  Hydrogen: 0.0000089,
  'Natural Gas': 0.000011,
  Methanol: 0.00059,
  Toluene: 0.00059,
  Diesel: 0.003,
  Naphtha: 0.0006,
  Kerosene: 0.0016,
  'Lube Oil': 0.04,
  'Amine (MEA)': 0.0025,
  'Caustic Soda': 0.003,
};
const RHO: any = {
  Water: 998,
  'Steam (condensing)': 2.5,
  Air: 1.2,
  'Crude Oil': 850,
  Benzene: 879,
  Ethanol: 789,
  Glycol: 1113,
  Ammonia: 682,
  Hydrogen: 0.089,
  'Natural Gas': 0.8,
  Methanol: 791,
  Toluene: 867,
  Diesel: 840,
  Naphtha: 720,
  Kerosene: 800,
  'Lube Oil': 880,
  'Amine (MEA)': 1010,
  'Caustic Soda': 1200,
};
const KC: any = {
  Water: 0.606,
  'Steam (condensing)': 0.025,
  Air: 0.026,
  'Crude Oil': 0.14,
  Benzene: 0.142,
  Ethanol: 0.167,
  Glycol: 0.258,
  Ammonia: 0.507,
  Hydrogen: 0.182,
  'Natural Gas': 0.033,
  Methanol: 0.202,
  Toluene: 0.138,
  Diesel: 0.13,
  Naphtha: 0.12,
  Kerosene: 0.135,
  'Lube Oil': 0.15,
  'Amine (MEA)': 0.49,
  'Caustic Soda': 0.62,
};
const U_BASE: any = {
  'Water-Water': 1000,
  'Water-Oil': 350,
  'Water-Gas': 80,
  'Steam-Water': 1800,
  'Steam-Oil': 500,
  'Oil-Oil': 200,
  'Gas-Gas': 50,
  'Water-Air': 75,
  'Water-Ammonia': 1200,
  'Oil-Gas': 60,
  'Steam-Gas': 120,
};
const FOULING: any = {
  'Clean/Steam (0.0001)': 0.0001,
  'Treated CW (0.0002)': 0.0002,
  'Cooling Tower (0.0004)': 0.0004,
  'River Water (0.0006)': 0.0006,
  'Seawater (0.0001)': 0.0001,
  'Light HC (0.0002)': 0.0002,
  'Crude <120°C (0.0006)': 0.0006,
  'Crude >120°C (0.001)': 0.001,
  'Heavy Fuel Oil (0.002)': 0.002,
  'Amine (0.0002)': 0.0002,
  'BFW (0.0002)': 0.0002,
};
const SHELL_TYPES: any = {
  'E — Single Pass': {
    Ft: 1.0,
    desc: 'Most common. ~80% of all HX. Best for Ft correction.',
  },
  'F — Two Pass': {
    Ft: 0.96,
    desc: 'Longitudinal baffle. Higher effectiveness. Risk of bypass.',
  },
  'G — Split Flow': {
    Ft: 0.94,
    desc: 'Low shell-side dP. Horizontal thermosyphon reboilers.',
  },
  'H — Double Split': { Ft: 0.93, desc: 'Very large shells, very low dP.' },
  'J — Divided Flow': {
    Ft: 0.91,
    desc: 'Two inlets, one central outlet. Condensers.',
  },
  'K — Kettle Reboiler': {
    Ft: 0.88,
    desc: 'Oversized shell. Bundle submerged in boiling liquid.',
  },
  'X — Cross Flow': {
    Ft: 0.85,
    desc: 'Pure crossflow. Extremely low dP. Gas/gas coolers.',
  },
};
const FRONT_HEAD: any = {
  'A — Removable Channel': {
    code: 'A',
    desc: 'Most common. Full tube access.',
  },
  'B — Integral Bonnet': { code: 'B', desc: 'Welded channel. Cheaper.' },
  'C — Integral Cover': { code: 'C', desc: 'High pressure.' },
  'N — Fixed TS Channel': { code: 'N', desc: 'Fixed tubesheet only.' },
  'D — High Pressure': { code: 'D', desc: '>100 bar service.' },
};
const BUNDLE_TYPES: any = {
  'AES — Floating Head Split Ring': {
    code: 'S',
    expand: true,
    desc: 'Most common in refineries. Bundle removable.',
  },
  'AET — Pull-Through Bundle': {
    code: 'T',
    expand: true,
    desc: 'Full bundle removal. Highest cost.',
  },
  'BEM — Fixed Tubesheet': {
    code: 'M',
    expand: false,
    desc: 'Cheapest. Need expansion joint if ΔT>50°C.',
  },
  'BEU — U-Tube': {
    code: 'U',
    expand: true,
    desc: 'Best for high P/T. Cannot clean inside tubes.',
  },
  'AEP — Packed Stuffing Box': {
    code: 'P',
    expand: true,
    desc: 'Low pressure <20 bar only.',
  },
};
const TEMA_CLASS: any = {
  'R — Refinery': { ca: 3.2, E: 1.0, inspect: 'Full RT+PWHT', test_f: 1.5 },
  'B — Chemical': { ca: 1.6, E: 0.85, inspect: 'Spot RT', test_f: 1.3 },
  'C — Commercial': { ca: 0.8, E: 0.7, inspect: 'Visual only', test_f: 1.3 },
};
const MATERIALS: any = {
  'Carbon Steel A516 Gr.70': {
    f: 1.0,
    Sm: 137,
    max_T: 425,
    max_P: 250,
    rho: 7850,
    spec: 'SA-516 Gr.70',
  },
  'Stainless Steel 304L': {
    f: 1.45,
    Sm: 115,
    max_T: 815,
    max_P: 300,
    rho: 7900,
    spec: 'SA-312 TP304L',
  },
  'Stainless Steel 316L': {
    f: 1.6,
    Sm: 115,
    max_T: 870,
    max_P: 300,
    rho: 7980,
    spec: 'SA-312 TP316L',
  },
  'Duplex SS 2205': {
    f: 2.1,
    Sm: 172,
    max_T: 315,
    max_P: 400,
    rho: 7805,
    spec: 'SA-789 S31803',
  },
  'Super Duplex 2507': {
    f: 2.4,
    Sm: 207,
    max_T: 260,
    max_P: 450,
    rho: 7810,
    spec: 'SA-789 S32750',
  },
  'Admiralty Brass': {
    f: 1.3,
    Sm: 82,
    max_T: 200,
    max_P: 100,
    rho: 8525,
    spec: 'SB-111 C44300',
  },
  'Titanium Gr.2': {
    f: 2.8,
    Sm: 103,
    max_T: 315,
    max_P: 250,
    rho: 4510,
    spec: 'SB-338 Gr.2',
  },
  'Hastelloy C-276': {
    f: 3.2,
    Sm: 207,
    max_T: 650,
    max_P: 350,
    rho: 8890,
    spec: 'SB-622 N10276',
  },
  'Inconel 625': {
    f: 3.5,
    Sm: 310,
    max_T: 980,
    max_P: 400,
    rho: 8440,
    spec: 'SB-444 N06625',
  },
  'Monel 400': {
    f: 2.1,
    Sm: 138,
    max_T: 480,
    max_P: 280,
    rho: 8830,
    spec: 'SB-165 N04400',
  },
};
const TUBE_OD_MAP: any = {
  '15.88mm (5/8")': 0.01588,
  '19.05mm (3/4")': 0.01905,
  '25.4mm (1")': 0.0254,
  '31.75mm (1¼")': 0.03175,
  '38.1mm (1½")': 0.0381,
};
const PITCH_MAP: any = {
  '25mm Triangular 30°': { p: 0.025, Cl: 0.87 },
  '25mm Square 90°': { p: 0.025, Cl: 1.0 },
  '32mm Triangular 30°': { p: 0.032, Cl: 0.87 },
  '32mm Square 90°': { p: 0.032, Cl: 1.0 },
  '25mm Rot.Square 45°': { p: 0.025, Cl: 1.0 },
};
const GASKETS = [
  'Spiral Wound SS304/Graphite',
  'Spiral Wound SS316L/Graphite',
  'PTFE Ring',
  'Ring Joint Soft Iron',
  'Ring Joint SS304',
  'Ring Joint Inconel',
  'CAF (Compressed Asbestos Free)',
];
const FASTENERS = [
  'A193 B7 / A194 2H',
  'A193 B7M / A194 2HM',
  'A320 L7 / A194 4',
  'A193 B8 / A194 8 (SS304)',
  'A193 B8M / A194 8M (SS316)',
];
const TUBE_TS = [
  'Expanded Only',
  'Expanded + Seal Welded',
  'Full Strength Weld',
  'Hydraulically Expanded',
];
const NOZZLE_SIZES = [
  '¾"',
  '1"',
  '1.5"',
  '2"',
  '3"',
  '4"',
  '6"',
  '8"',
  '10"',
  '12"',
  '14"',
  '16"',
];
const PIPE_SCHED = ['Sch 40', 'Sch 80', 'Sch 160', 'Sch XS', 'Sch XXS'];
const FLANGE_CLASS = ['150#', '300#', '600#', '900#', '1500#', '2500#'];
const FLANGE_FACE = [
  'RF — Raised Face',
  'RTJ — Ring Type Joint',
  'FF — Flat Face',
];
const PAINT_SPEC = [
  'Epoxy Primer + Polyurethane',
  'Inorganic Zinc + Epoxy',
  'Hot Dip Galvanized',
  'Bare Metal (SS)',
  'Phenolic Epoxy',
];
const SHIP_COND = [
  'Dry — Nitrogen Blanketed',
  'Oil Flushed & Sealed',
  'Dry — Open',
  'Water Filled',
];
const NAMEPLATE = [
  'ASME U-Stamp',
  'PED (CE Mark)',
  'ASME + PED',
  'ATEX Zone 1',
  'No Stamp',
];
const ORIENTATION_OPT = [
  'Horizontal',
  'Vertical — Head Up',
  'Vertical — Head Down',
];
const BYPASS_SEAL = ['Sealing Strips', 'Tie Rods Only', 'Full Bypass Blocked'];
const IMPINGEMENT = [
  'None Required',
  'Impingement Plate',
  'Impingement Rods',
  'Distributor Nozzle',
];
const SURFACE_FINISH = [
  'Not Specified',
  'Ra 0.8 μm (Pharma)',
  'Ra 1.6 μm (Food)',
  'Ra 3.2 μm (Standard)',
  'Electropolished',
];
const FLUID_PHASE = [
  'Liquid',
  'Vapor / Gas',
  'Two-Phase (Condensing)',
  'Two-Phase (Vaporizing)',
  'Steam Condensing',
];

function classify(f: string) {
  return [
    'Water',
    'Steam (condensing)',
    'Ammonia',
    'Caustic Soda',
    'Amine (MEA)',
  ].includes(f)
    ? 'Water'
    : ['Air', 'Hydrogen', 'Natural Gas'].includes(f)
    ? 'Gas'
    : 'Oil';
}
function getU(h: string, c: string) {
  const hc = classify(h),
    cc = classify(c);
  return U_BASE[`${hc}-${cc}`] || U_BASE[`${cc}-${hc}`] || 200;
}
function Pr(f: string) {
  return (CP[f] * 1000 * MU[f]) / KC[f];
}
function nozzleDia(s: string): number {
  const m: any = {
    '¾"': 0.02191,
    '1"': 0.02664,
    '1.5"': 0.04089,
    '2"': 0.05252,
    '3"': 0.07792,
    '4"': 0.10226,
    '6"': 0.15405,
    '8"': 0.20275,
    '10"': 0.25451,
    '12"': 0.30378,
    '14"': 0.3334,
    '16"': 0.381,
  };
  return m[s] || 0.1;
}

// Colors - Light professional theme
const C = {
  bg: '#f0f2f5',
  panel: '#ffffff',
  panelAlt: '#f8f9fb',
  border: '#dde3ea',
  borderStrong: '#c5cdd8',
  accent: '#1a6eb5',
  accentLt: '#e8f0fa',
  success: '#0d8050',
  successLt: '#e6f7f0',
  warning: '#b86800',
  warningLt: '#fff3e0',
  danger: '#c0392b',
  dangerLt: '#fdecea',
  purple: '#6d28d9',
  purpleLt: '#f5f0ff',
  text: '#1a2332',
  textMid: '#4a5568',
  textDim: '#8896a8',
  header: '#1a2740',
  tabBg: '#eef1f5',
};

const CSS = `
  *{box-sizing:border-box;margin:0;padding:0;}
  body{font-family:'Segoe UI',sans-serif;background:#f0f2f5;}
  ::-webkit-scrollbar{width:5px;height:5px;}
  ::-webkit-scrollbar-track{background:#f0f2f5;}
  ::-webkit-scrollbar-thumb{background:#c0c8d0;border-radius:3px;}
  select option{background:#fff;color:#1a2332;}
  input[type=number]::-webkit-inner-spin-button{opacity:0.4;}
  input[type=checkbox]{accent-color:#1a6eb5;}
  @media print{
    .no-print{display:none!important;}
    #hx-printable{display:block!important;}
    body{background:#fff!important;}
  }
`;

const iSt: any = {
  width: '100%',
  background: '#fff',
  border: `1px solid ${C.border}`,
  borderRadius: 4,
  padding: '5px 8px',
  color: C.text,
  fontSize: 11,
  fontFamily: 'inherit',
  outline: 'none',
};
const lSt: any = {
  display: 'block',
  fontSize: 9,
  color: C.textDim,
  letterSpacing: 0.8,
  marginBottom: 2,
  fontWeight: 600,
  textTransform: 'uppercase' as const,
};

const F = ({ label, value, onChange, unit, options, hint, text }: any) => (
  <div style={{ marginBottom: 8 }}>
    {label && <label style={lSt}>{label}</label>}
    {options ? (
      <select
        value={value}
        onChange={(e: any) => onChange(e.target.value)}
        style={{ ...iSt, paddingRight: 4 }}
      >
        {options.map((o: any) => (
          <option key={o}>{o}</option>
        ))}
      </select>
    ) : (
      <div style={{ position: 'relative' }}>
        <input
          type={text ? 'text' : 'number'}
          value={value}
          onChange={(e: any) => onChange(e.target.value)}
          style={{ ...iSt, paddingRight: unit ? 38 : 8 }}
        />
        {unit && (
          <span
            style={{
              position: 'absolute',
              right: 6,
              top: '50%',
              transform: 'translateY(-50%)',
              fontSize: 9,
              color: C.textDim,
              pointerEvents: 'none',
            }}
          >
            {unit}
          </span>
        )}
      </div>
    )}
    {hint && (
      <div
        style={{ fontSize: 8, color: C.textDim, marginTop: 2, lineHeight: 1.4 }}
      >
        {hint}
      </div>
    )}
  </div>
);

const SH = ({ t, c = C.accent }: any) => (
  <div
    style={{
      background: C.accentLt,
      borderLeft: `3px solid ${c}`,
      padding: '4px 8px',
      margin: '6px 0 4px',
    }}
  >
    <span
      style={{
        fontSize: 9,
        color: c,
        letterSpacing: 1,
        fontWeight: 700,
        textTransform: 'uppercase' as const,
      }}
    >
      {t}
    </span>
  </div>
);

const RW = ({ k, v, u, hi, warn, sub, bold }: any) => (
  <div
    style={{
      display: 'flex',
      alignItems: 'center',
      borderBottom: `1px solid ${C.border}`,
      padding: sub ? '4px 12px 4px 22px' : '4px 12px',
      background: hi ? C.successLt : warn ? C.dangerLt : C.panel,
    }}
  >
    <span style={{ flex: 1, color: sub ? C.textDim : C.textMid, fontSize: 10 }}>
      {k}
    </span>
    <span
      style={{
        color: hi ? C.success : warn ? C.danger : C.text,
        fontSize: 10,
        fontWeight: bold ? 700 : 600,
        fontFamily: 'monospace',
      }}
    >
      {v}
      {u && (
        <span style={{ fontSize: 8, color: C.textDim, fontWeight: 400 }}>
          {' '}
          {u}
        </span>
      )}
    </span>
  </div>
);

// ═══════════════════════════════════════════════════════
// MAIN CALC ENGINE
// ═══════════════════════════════════════════════════════
function doCalc(inp: any) {
  const {
    hFluid,
    cFluid,
    hTin,
    hTout,
    cTin,
    cTout,
    hFlow,
    hDesP,
    cDesP,
    hDesT,
    cDesT,
    hFoul,
    cFoul,
    shellType,
    frontHead,
    bundleType,
    temaClass,
    tubePasses,
    tubeODK,
    tubeThk,
    tubeLen,
    pitchK,
    baffleCut,
    baffleSpacing,
    matShell,
    matTube,
    jointEff,
    hInN,
    cInN,
    hPhase,
    useCustomH,
    useCustomC,
    cRho_h,
    cMu_h,
    cCp_h,
    cK_h,
    cRho_c,
    cMu_c,
    cCp_c,
    cK_c,
  } = inp;

  const T1 = +hTin,
    T2 = +hTout,
    t1 = +cTin,
    t2 = +cTout,
    mh = +hFlow;
  if (T2 >= T1 || t2 <= t1 || T2 <= t1 || mh <= 0) return null;

  // Fluid properties
  const cp_h = useCustomH ? +cCp_h : CP[hFluid];
  const mu_h = useCustomH ? +cMu_h / 1000 : MU[hFluid];
  const rho_h = useCustomH ? +cRho_h : RHO[hFluid];
  const k_h = useCustomH ? +cK_h : KC[hFluid];
  const cp_c = useCustomC ? +cCp_c : CP[cFluid];
  const mu_c = useCustomC ? +cMu_c / 1000 : MU[cFluid];
  const rho_c = useCustomC ? +cRho_c : RHO[cFluid];
  const k_c = useCustomC ? +cK_c : KC[cFluid];

  const Q = mh * cp_h * (T1 - T2);
  const mc = Q / (cp_c * (t2 - t1));
  const dT1 = T1 - t2,
    dT2 = T2 - t1;
  if (dT1 <= 0 || dT2 <= 0) return null;
  const lmtd =
    Math.abs(dT1 - dT2) < 0.01 ? dT1 : (dT1 - dT2) / Math.log(dT1 / dT2);
  const R = (T1 - T2) / (t2 - t1),
    S = (t2 - t1) / (T1 - t1);
  const shFt = SHELL_TYPES[shellType]?.Ft || 1.0;
  let Ft = shFt;
  if (R !== 1 && S > 0 && S < 1) {
    try {
      const W = ((1 - S * R) / (1 - S)) ** (1 / +tubePasses);
      const num = Math.sqrt(R * R + 1) * Math.log(W);
      const den =
        (R - 1) *
        Math.log(
          (2 - S * (R + 1 - Math.sqrt(R * R + 1))) /
            (2 - S * (R + 1 + Math.sqrt(R * R + 1)))
        );
      if (Math.abs(den) > 0.001) Ft = shFt * Math.min(1, Math.abs(num / den));
    } catch (e) {}
  }
  Ft = Math.max(0.6, Math.min(1.0, Ft));

  const Rf_h = FOULING[hFoul] || 0.0006,
    Rf_c = FOULING[cFoul] || 0.0004;
  const U_cl =
    getU(useCustomH ? 'Custom' : hFluid, useCustomC ? 'Custom' : cFluid) *
    MATERIALS[matTube].f;
  const U_dir = 1 / (1 / U_cl + Rf_h + Rf_c);
  const overdesign = (U_cl / U_dir - 1) * 100;
  const A_req = (Q * 1000) / (U_dir * lmtd * Ft);

  // Tube geometry
  const OD = TUBE_OD_MAP[tubeODK],
    thk = +tubeThk / 1000,
    ID = OD - 2 * thk,
    L = +tubeLen;
  const { p: pitch, Cl } = PITCH_MAP[pitchK];
  const A_per_tube = Math.PI * OD * L;

  // Step-by-step tube count
  const Nt_calc = A_req / A_per_tube;
  const Nt = Math.ceil(Nt_calc);
  const Ntp = Math.ceil(Nt / +tubePasses);
  const CTP = +tubePasses === 1 ? 0.93 : +tubePasses === 2 ? 0.9 : 0.85;
  const Ds =
    0.637 * Math.sqrt(Cl / CTP) * Math.sqrt((Nt * pitch * pitch) / 0.785);
  const A_actual = Nt * A_per_tube;
  const overdesign_actual = (A_actual / A_req - 1) * 100;
  const shells = Math.max(1, Math.ceil(A_req / (A_per_tube * Nt)));

  const Bs = +baffleSpacing / 1000,
    Nb = Math.max(1, Math.floor(L / Bs) - 1);
  const tc = TEMA_CLASS[temaClass];
  const E = +jointEff || tc.E;
  const Sm = MATERIALS[matShell].Sm;
  const t_sh =
    (+hDesP * 10 * Ds * 1000) / 2 / (Sm * E * 1000 - 0.6 * (+hDesP * 10)) +
    tc.ca;

  const at = (Math.PI * ID * ID) / 4,
    At = at * Ntp;
  const Asf = (Ds * Bs * (pitch - OD)) / pitch;
  const vt = mc / (rho_c * Math.max(At, 0.0001));
  const vs = mh / (rho_h * Math.max(Asf, 0.0001));

  const Pr_h = (cp_h * 1000 * mu_h) / k_h;
  const Pr_c = (cp_c * 1000 * mu_c) / k_c;
  const Re_t = (rho_c * vt * ID) / mu_c;
  const Re_s = (rho_h * vs * OD) / mu_h;
  const Nu_t =
    Re_t > 10000
      ? 0.023 * Re_t ** 0.8 * Pr_c ** 0.4
      : Re_t > 2300
      ? 0.116 * (Re_t ** (2 / 3) - 125) * Pr_c ** (1 / 3)
      : 3.66;
  const ht = (Nu_t * k_c) / ID;
  const Nu_s = 0.36 * Re_s ** 0.55 * Pr_h ** (1 / 3);
  const hs = (Nu_s * k_h) / OD;
  const ft = Re_t > 2300 ? 0.316 * Re_t ** -0.25 : 64 / Re_t;
  const dPt = (ft * ((L * +tubePasses) / ID) * rho_c * vt ** 2) / 2 / 1000;
  const dPs = (0.72 * Nb * rho_h * vs ** 2) / 2 / 1000;
  const Cmin = Math.min(mh * cp_h, mc * cp_c) * 1000,
    Cmax = Math.max(mh * cp_h, mc * cp_c) * 1000;
  const Cr = Cmin / Cmax,
    NTU = (U_dir * A_req) / Cmin;
  const eff =
    (1 - Math.exp(-NTU * (1 - Cr))) / (1 - Cr * Math.exp(-NTU * (1 - Cr)));
  const rv2_hin =
    rho_h * ((4 * mh) / (rho_h * Math.PI * nozzleDia(hInN) ** 2)) ** 2;
  const rv2_cin =
    rho_c * ((4 * mc) / (rho_c * Math.PI * nozzleDia(cInN) ** 2)) ** 2;
  const vs_bundle = mh / (rho_h * Math.max(Asf, 0.0001));
  const rv2_bundle = rho_h * vs_bundle ** 2;
  const imp_limit = [
    'Vapor / Gas',
    'Two-Phase (Condensing)',
    'Two-Phase (Vaporizing)',
    'Steam Condensing',
  ].includes(hPhase)
    ? 744
    : 2230;
  const imp_req = rv2_hin > imp_limit;
  const rhoM = MATERIALS[matTube].rho;
  const W_tubes = ((Nt * L * Math.PI * (OD ** 2 - ID ** 2)) / 4) * rhoM;
  const W_shell = Math.PI * Ds * (t_sh / 1000) * L * MATERIALS[matShell].rho;
  const W_empty = Math.round(W_tubes + W_shell + 800);
  const W_oper = Math.round(
    W_empty + Nt * L * at * rho_c + 0.6 * Math.PI * (Ds / 2) ** 2 * L * rho_h
  );
  const W_hydro = Math.round(
    W_empty + Nt * L * at * 998 + 0.6 * Math.PI * (Ds / 2) ** 2 * L * 998
  );
  const dT_exp = Math.abs(+hDesT - +cDesT);
  const exp_req =
    dT_exp > 50 && !BUNDLE_TYPES[bundleType]?.expand ? 'YES — Required' : 'NO';
  const f_nat =
    ((3.52 / (2 * Math.PI)) *
      Math.sqrt(
        (2e11 * ((Math.PI * (OD ** 4 - ID ** 4)) / 64)) /
          ((rhoM * Math.PI * (OD ** 2 - ID ** 2)) / 4)
      )) /
    L ** 2;
  const v_crit = 0.4 * f_nat * OD;
  const vib = vs > v_crit * 0.7 ? 'HIGH ⚠' : 'LOW ✓';
  const cost = Math.round(
    (10000 + A_req * 800 + (shells - 1) * 5500) * MATERIALS[matShell].f
  );
  const P_test_sh = (+hDesP * tc.test_f).toFixed(1);
  const P_test_tu = (+cDesP * tc.test_f).toFixed(1);
  const fhCode = FRONT_HEAD[frontHead]?.code || 'A';
  const shCode = shellType.split('—')[0].trim().split(' ')[0];
  const rrCode = BUNDLE_TYPES[bundleType]?.code || 'S';
  const temaDesig = `${fhCode}${shCode}${rrCode}`;

  // Fouling degradation over time
  const foulData = [];
  for (let month = 0; month <= 24; month += 1) {
    const frac = Math.min(1, month / 18);
    const Rf_h_t = Rf_h * frac,
      Rf_c_t = Rf_c * frac;
    const U_t = 1 / (1 / U_cl + Rf_h_t + Rf_c_t);
    const Q_t = (U_t * A_actual * lmtd * Ft) / 1000;
    const duty_pct = (Q_t / Q) * 100;
    const Tout_actual = T1 - Q_t / mh / cp_h;
    foulData.push({
      month,
      U: Math.round(U_t),
      duty_pct: +duty_pct.toFixed(1),
      Tout: +Tout_actual.toFixed(1),
      clean_needed: duty_pct < 90,
    });
  }

  // Variable flow study
  const flowData = [];
  for (let pct = 30; pct <= 150; pct += 10) {
    const mh_v = (mh * pct) / 100;
    const Q_v = mh_v * cp_h * (T1 - T2);
    const mc_v = Q_v / (cp_c * (t2 - t1));
    const vt_v = mc_v / (rho_c * Math.max(At, 0.0001));
    const vs_v = mh_v / (rho_h * Math.max(Asf, 0.0001));
    const Re_t_v = (rho_c * vt_v * ID) / mu_c;
    const Re_s_v = (rho_h * vs_v * OD) / mu_h;
    const ft_v =
      Re_t_v > 2300 ? 0.316 * Re_t_v ** -0.25 : 64 / Math.max(Re_t_v, 1);
    const dPt_v =
      (ft_v * ((L * +tubePasses) / ID) * rho_c * vt_v ** 2) / 2 / 1000;
    const dPs_v = (0.72 * Nb * rho_h * vs_v ** 2) / 2 / 1000;
    flowData.push({
      flow_pct: pct,
      flow: +mh_v.toFixed(2),
      Q: +Q_v.toFixed(0),
      vt: +vt_v.toFixed(2),
      vs: +vs_v.toFixed(2),
      dPt: +dPt_v.toFixed(1),
      dPs: +dPs_v.toFixed(1),
      Re_t: Math.round(Re_t_v),
      ok_vt: vt_v >= 0.5 && vt_v <= 3,
      ok_vs: vs_v <= 2,
      ok_dPt: dPt_v <= 100,
      ok_dPs: dPs_v <= 80,
    });
  }

  // Shell type comparison
  const shellComps = Object.entries(SHELL_TYPES)
    .slice(0, 3)
    .map(([name, data]: any) => {
      const ft_s = data.Ft;
      const A_s = (Q * 1000) / (U_dir * lmtd * ft_s);
      const Nt_s = Math.ceil(A_s / A_per_tube);
      return {
        name: name.split('—')[0].trim(),
        Ft: ft_s,
        A: A_s.toFixed(1),
        Nt: Nt_s,
        cost: Math.round((10000 + A_s * 800) * MATERIALS[matShell].f),
      };
    });

  return {
    Q: Q.toFixed(1),
    Q_MW: (Q / 1000).toFixed(3),
    mc: mc.toFixed(3),
    lmtd: lmtd.toFixed(2),
    R: R.toFixed(3),
    S: S.toFixed(3),
    Ft: Ft.toFixed(3),
    eff_lmtd: (lmtd * Ft).toFixed(2),
    U_cl: U_cl.toFixed(0),
    U_dir: U_dir.toFixed(0),
    overdesign: overdesign.toFixed(1),
    overdesign_actual: overdesign_actual.toFixed(1),
    A_req: A_req.toFixed(2),
    A_actual: A_actual.toFixed(2),
    NTU: NTU.toFixed(3),
    eff: (eff * 100).toFixed(1),
    ht: ht.toFixed(0),
    hs: hs.toFixed(0),
    // Tube count step by step
    Nt_calc: Nt_calc.toFixed(1),
    Nt,
    Ntp,
    A_per_tube: A_per_tube.toFixed(4),
    OD_mm: (OD * 1000).toFixed(2),
    ID_mm: (ID * 1000).toFixed(2),
    L,
    Ds_mm: (Ds * 1000).toFixed(0),
    shells,
    Nb,
    Bs_mm: +baffleSpacing,
    t_sh: t_sh.toFixed(1),
    Sm,
    E,
    ca: tc.ca,
    vt: vt.toFixed(3),
    vs: vs.toFixed(3),
    Re_t: Re_t.toFixed(0),
    Re_s: Re_s.toFixed(0),
    Pr_t: Pr_c.toFixed(2),
    Pr_s: Pr_h.toFixed(2),
    dPt: dPt.toFixed(2),
    dPs: dPs.toFixed(2),
    rv2_hin: rv2_hin.toFixed(0),
    rv2_cin: rv2_cin.toFixed(0),
    rv2_bundle: rv2_bundle.toFixed(0),
    imp_req,
    imp_limit,
    W_empty,
    W_oper,
    W_hydro,
    P_test_sh,
    P_test_tu,
    exp_req,
    vib,
    cost: cost.toLocaleString(),
    temaDesig,
    flow_t:
      Re_t > 10000
        ? 'Turbulent ✓'
        : Re_t > 2300
        ? 'Transitional ⚠'
        : 'Laminar ✗',
    flow_s: Re_s > 1000 ? 'Turbulent ✓' : 'Laminar ⚠',
    warn_vt: vt < 0.5 || vt > 3,
    warn_vs: vs > 2,
    warn_dPt: dPt > 100,
    warn_dPs: dPs > 80,
    warn_Ft: Ft < 0.75,
    warn_rv2_h: rv2_hin > imp_limit,
    warn_matT: +hDesT > MATERIALS[matTube].max_T,
    foulData,
    flowData,
    shellComps,
    // For selector
    dT_shell_tube: dT_exp,
    is_fouling: Rf_h > 0.0005 || Rf_c > 0.0005,
    is_high_pressure: +hDesP > 50 || +cDesP > 50,
    Rf_h,
    Rf_c,
    pitch,
    OD,
    mh,
    mc,
    cp_h,
    cp_c,
    rho_h,
    rho_c,
  };
}

// ═══════════════════════════════════════════════════════
// HX TYPE SELECTOR LOGIC
// ═══════════════════════════════════════════════════════
function getHXRecommendation(r: any, inp: any) {
  const recs: any[] = [];
  const { hFluid, cFluid, bundleType, useCustomH, useCustomC } = inp;
  const dT = r.dT_shell_tube;
  const fouling = r.is_fouling;
  const hiP = r.is_high_pressure;

  // AES Floating Head
  let aes_score = 0,
    aes_reasons: string[] = [],
    aes_warnings: string[] = [];
  if (dT > 50) {
    aes_score += 3;
    aes_reasons.push(
      `ΔT=${dT.toFixed(0)}°C > 50°C — floating head handles thermal expansion`
    );
  }
  if (fouling) {
    aes_score += 3;
    aes_reasons.push('High fouling service — bundle removable for cleaning');
  }
  if (!hiP) {
    aes_score += 2;
    aes_reasons.push('Pressure within AES design range');
  }
  if (hiP) {
    aes_warnings.push('High pressure — verify split ring design limits');
  }
  recs.push({
    name: 'AES — Floating Head Split Ring',
    score: aes_score,
    reasons: aes_reasons,
    warnings: aes_warnings,
    suitable: aes_score >= 4,
  });

  // BEU U-Tube
  let beu_score = 0,
    beu_reasons: string[] = [],
    beu_warnings: string[] = [];
  if (dT > 50) {
    beu_score += 3;
    beu_reasons.push(
      'U-tubes absorb differential expansion without expansion joint'
    );
  }
  if (hiP) {
    beu_score += 3;
    beu_reasons.push('Excellent for high pressure — no rear tubesheet seal');
  }
  if (!fouling) {
    beu_score += 2;
    beu_reasons.push('Clean service — mechanical tube cleaning not needed');
  }
  if (fouling) {
    beu_warnings.push(
      '⚠ Cannot mechanically clean inside of U-tubes — not recommended for fouling tube side'
    );
  }
  recs.push({
    name: 'BEU — U-Tube Bundle',
    score: beu_score,
    reasons: beu_reasons,
    warnings: beu_warnings,
    suitable: beu_score >= 4 && !fouling,
  });

  // BEM Fixed Tubesheet
  let bem_score = 0,
    bem_reasons: string[] = [],
    bem_warnings: string[] = [];
  if (dT <= 50) {
    bem_score += 4;
    bem_reasons.push(
      `ΔT=${dT.toFixed(0)}°C ≤ 50°C — no expansion joint needed for fixed TS`
    );
  }
  if (!fouling) {
    bem_score += 2;
    bem_reasons.push('Clean service — no need for bundle removal');
  }
  bem_reasons.push('Cheapest construction — no floating head components');
  if (dT > 50) {
    bem_warnings.push(
      `⚠ ΔT=${dT.toFixed(0)}°C > 50°C — expansion joint REQUIRED on shell`
    );
  }
  if (fouling) {
    bem_warnings.push(
      '⚠ Bundle cannot be removed — difficult to clean shell side'
    );
  }
  recs.push({
    name: 'BEM — Fixed Tubesheet',
    score: bem_score,
    reasons: bem_reasons,
    warnings: bem_warnings,
    suitable: bem_score >= 4,
  });

  // AET Pull-Through
  let aet_score = 0,
    aet_reasons: string[] = [],
    aet_warnings: string[] = [];
  if (fouling) {
    aet_score += 4;
    aet_reasons.push(
      'Best for heavy fouling — full bundle removal without unbolting shell covers'
    );
  }
  if (dT > 50) {
    aet_score += 2;
    aet_reasons.push('Full floating head handles thermal expansion');
  }
  aet_warnings.push('Most expensive design — only justify for severe fouling');
  recs.push({
    name: 'AET — Pull-Through Bundle',
    score: aet_score,
    reasons: aet_reasons,
    warnings: aet_warnings,
    suitable: aet_score >= 4,
  });

  recs.sort((a, b) => b.score - a.score);
  return recs;
}

// ═══════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════
export default function HXCalc() {
  // Process
  const [hFluid, sHF] = useState('Crude Oil');
  const [cFluid, sCF] = useState('Water');
  const [hPhase, sHP] = useState('Liquid');
  const [cPhase, sCP] = useState('Liquid');
  const [hTin, sHTi] = useState(180);
  const [hTout, sHTo] = useState(90);
  const [cTin, sCTi] = useState(25);
  const [cTout, sCTo] = useState(65);
  const [hFlow, sHFl] = useState(5);
  const [hOpP, sHOpP] = useState(8);
  const [hDesP, sHDP] = useState(10);
  const [cOpP, sCOpP] = useState(6);
  const [cDesP, sCDP] = useState(8);
  const [hOpT, sHOpT] = useState(180);
  const [cOpT, sCOpT] = useState(65);
  const [hDesT, sHDT] = useState(200);
  const [cDesT, sCDT] = useState(80);
  const [hSteamP, sHSP] = useState(3.5);
  const [hSteamT, sHST] = useState(150);
  const [hVapFrac, sHVF] = useState(0);
  const [hDewPt, sHDew] = useState('N/A');
  const [hFoul, sHFo] = useState('Crude <120°C (0.0006)');
  const [cFoul, sCFo] = useState('Cooling Tower (0.0004)');
  const [hPstart, sHPs] = useState(11);
  const [hTstart, sHTs] = useState(210);
  const [hPupset, sHPu] = useState(12);
  const [hTupset, sHTu] = useState(220);
  // Custom fluid
  const [useCustomH, setUseCustomH] = useState(false);
  const [cRho_h, setCRho_h] = useState(850);
  const [cMu_h, setCMu_h] = useState(25);
  const [cCp_h, setCCp_h] = useState(2.1);
  const [cK_h, setCK_h] = useState(0.14);
  const [useCustomC, setUseCustomC] = useState(false);
  const [cRho_c, setCRho_c] = useState(998);
  const [cMu_c, setCMu_c] = useState(1.0);
  const [cCp_c, setCCp_c] = useState(4.187);
  const [cK_c, setCK_c] = useState(0.606);
  // Geometry
  const [shellType, sST] = useState('E — Single Pass');
  const [frontHead, sFH] = useState('A — Removable Channel');
  const [bundleType, sBT] = useState('AES — Floating Head Split Ring');
  const [temaClass, sTC] = useState('R — Refinery');
  const [tubePasses, sTP] = useState(2);
  const [tubeODK, sTOD] = useState('19.05mm (3/4")');
  const [tubeThk, sTTh] = useState(2.11);
  const [tubeLen, sTL] = useState(4.88);
  const [pitchK, sPK] = useState('25mm Triangular 30°');
  const [baffleCut, sBC] = useState(25);
  const [baffleSpacing, sBS] = useState(200);
  const [inletBaffle, sIB] = useState(250);
  const [bypassSeal, sBPS] = useState('Sealing Strips');
  const [impingement, sImp] = useState('Impingement Plate');
  const [tubeTSJoint, sTTSJ] = useState('Expanded + Seal Welded');
  // Mechanical
  const [matShell, sMSh] = useState('Carbon Steel A516 Gr.70');
  const [matTube, sMTu] = useState('Carbon Steel A516 Gr.70');
  const [matGasket, sMG] = useState('Spiral Wound SS304/Graphite');
  const [matFastener, sMF] = useState('A193 B7 / A194 2H');
  const [spareGaskets, sSG] = useState(2);
  const [jointEff, sJE] = useState(1.0);
  const [orientation, sOR] = useState('Horizontal');
  const [insulReq, sIR] = useState('Yes');
  const [insulThk, sIT] = useState(50);
  const [surfFinish, sSF] = useState('Not Specified');
  const [paintSpec, sPSp] = useState('Epoxy Primer + Polyurethane');
  const [shipCond, sSC] = useState('Dry — Nitrogen Blanketed');
  const [nameplate, sNP] = useState('ASME U-Stamp');
  const [api660, sAPI] = useState('Yes');
  const [uStamp, sUS] = useState('Yes');
  const [numSaddles, sNS] = useState(2);
  // Nozzles
  const [hInN, sHIN] = useState('4"');
  const [hOutN, sHON] = useState('4"');
  const [cInN, sCIN] = useState('3"');
  const [cOutN, sCON] = useState('3"');
  const [ventN, sVN] = useState('1"');
  const [drainN, sDN] = useState('1"');
  const [hInSch, sHIS] = useState('Sch 80');
  const [hOutSch, sHOS] = useState('Sch 80');
  const [cInSch, sCIS] = useState('Sch 80');
  const [cOutSch, sCOS] = useState('Sch 80');
  const [flangeClass, sFC] = useState('300#');
  const [flangeFace, sFF] = useState('RF — Raised Face');
  const [hInLine, sHIL] = useState('4"-HC-1001-A1A');
  const [hOutLine, sHOL] = useState('4"-HC-1002-A1A');
  const [cInLine, sCIL] = useState('3"-CW-2001-A1A');
  const [cOutLine, sCOL] = useState('3"-CW-2002-A1A');
  // Constraints
  const [maxArea, setMaxArea] = useState(0);
  const [minArea, setMinArea] = useState(0);
  const [maxDPs, setMaxDPs] = useState(0);
  const [maxDPt, setMaxDPt] = useState(0);
  const [maxDs, setMaxDs] = useState(0);
  const [maxOD_c, setMaxOD_c] = useState(0);
  const [maxOverdesign, setMaxOverdesign] = useState(0);
  // Project
  const [projName, sPRN] = useState('Crude Preheat Train');
  const [plantLoc, sPL] = useState('Refinery Unit 100');
  const [eqTag, sET] = useState('E-101');
  const [client, sCL] = useState('Client Name');
  const [prepBy, sPB] = useState('Engineer Name');
  const [chkBy, sCB] = useState('Lead Engineer');
  const [appBy, sAB] = useState('Department Head');
  const [docNo, sDN2] = useState('DS-E-101-001');
  const [revNo, sRN] = useState('A');
  const [revDesc, sRD] = useState('Issued for Review (IFR)');
  // Tabs
  const [lTab, setLTab] = useState('process');
  const [rTab, setRTab] = useState('thermal');

  const inp = useMemo(
    () => ({
      hFluid,
      cFluid,
      hTin,
      hTout,
      cTin,
      cTout,
      hFlow,
      hDesP,
      cDesP,
      hDesT,
      cDesT,
      hFoul,
      cFoul,
      shellType,
      frontHead,
      bundleType,
      temaClass,
      tubePasses,
      tubeODK,
      tubeThk,
      tubeLen,
      pitchK,
      baffleCut,
      baffleSpacing,
      matShell,
      matTube,
      jointEff,
      hInN,
      cInN,
      hPhase,
      useCustomH,
      useCustomC,
      cRho_h,
      cMu_h,
      cCp_h,
      cK_h,
      cRho_c,
      cMu_c,
      cCp_c,
      cK_c,
    }),
    [
      hFluid,
      cFluid,
      hTin,
      hTout,
      cTin,
      cTout,
      hFlow,
      hDesP,
      cDesP,
      hDesT,
      cDesT,
      hFoul,
      cFoul,
      shellType,
      frontHead,
      bundleType,
      temaClass,
      tubePasses,
      tubeODK,
      tubeThk,
      tubeLen,
      pitchK,
      baffleCut,
      baffleSpacing,
      matShell,
      matTube,
      jointEff,
      hInN,
      cInN,
      hPhase,
      useCustomH,
      useCustomC,
      cRho_h,
      cMu_h,
      cCp_h,
      cK_h,
      cRho_c,
      cMu_c,
      cCp_c,
      cK_c,
    ]
  );

  const r = useMemo(() => doCalc(inp), [inp]);
  const hxRecs = useMemo(
    () => (r ? getHXRecommendation(r, inp) : []),
    [r, inp]
  );

  // Constraint results
  const constraintResults = useMemo(() => {
    if (!r) return [];
    const res: any[] = [];
    if (maxArea > 0)
      res.push({
        name: 'Max Heat Transfer Area',
        val: `${r.A_req} m²`,
        limit: `${maxArea} m²`,
        ok: parseFloat(r.A_req) <= maxArea,
      });
    if (minArea > 0)
      res.push({
        name: 'Min Heat Transfer Area',
        val: `${r.A_req} m²`,
        limit: `${minArea} m²`,
        ok: parseFloat(r.A_req) >= minArea,
      });
    if (maxDPs > 0)
      res.push({
        name: 'Max Shell Side ΔP',
        val: `${r.dPs} kPa`,
        limit: `${maxDPs} kPa`,
        ok: parseFloat(r.dPs) <= maxDPs,
      });
    if (maxDPt > 0)
      res.push({
        name: 'Max Tube Side ΔP',
        val: `${r.dPt} kPa`,
        limit: `${maxDPt} kPa`,
        ok: parseFloat(r.dPt) <= maxDPt,
      });
    if (maxDs > 0)
      res.push({
        name: 'Max Shell Diameter',
        val: `${r.Ds_mm} mm`,
        limit: `${maxDs} mm`,
        ok: parseFloat(r.Ds_mm) <= maxDs,
      });
    if (maxOverdesign > 0)
      res.push({
        name: 'Max Overdesign',
        val: `${r.overdesign_actual}%`,
        limit: `${maxOverdesign}%`,
        ok: parseFloat(r.overdesign_actual) <= maxOverdesign,
      });
    return res;
  }, [r, maxArea, minArea, maxDPs, maxDPt, maxDs, maxOverdesign]);

  const LB = (t: string, l: string) => (
    <button
      onClick={() => setLTab(t)}
      style={{
        padding: '6px 8px',
        fontSize: 9,
        border: 'none',
        cursor: 'pointer',
        background: lTab === t ? C.panel : 'transparent',
        color: lTab === t ? C.accent : C.textMid,
        borderBottom:
          lTab === t ? `2px solid ${C.accent}` : '2px solid transparent',
        fontFamily: 'inherit',
        fontWeight: lTab === t ? 700 : 500,
        whiteSpace: 'nowrap' as const,
        borderRight: `1px solid ${C.border}`,
      }}
    >
      {l}
    </button>
  );
  const RB = (t: string, l: string) => (
    <button
      onClick={() => setRTab(t)}
      style={{
        padding: '6px 10px',
        fontSize: 9,
        border: 'none',
        cursor: 'pointer',
        background: rTab === t ? C.panel : C.tabBg,
        color: rTab === t ? C.accent : C.textMid,
        borderBottom:
          rTab === t ? `2px solid ${C.accent}` : '2px solid transparent',
        fontFamily: 'inherit',
        fontWeight: rTab === t ? 700 : 500,
        whiteSpace: 'nowrap' as const,
        borderRight: `1px solid ${C.border}`,
      }}
    >
      {l}
    </button>
  );

  return (
    <div
      style={{
        height: '100vh',
        background: C.bg,
        fontFamily: "'Segoe UI',sans-serif",
        color: C.text,
        display: 'flex',
        flexDirection: 'column',
        overflow: 'hidden',
      }}
    >
      <style>{CSS}</style>

      {/* HEADER */}
      <div
        className="no-print"
        style={{
          background: C.header,
          padding: '0 18px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          height: 50,
          flexShrink: 0,
          boxShadow: '0 2px 8px rgba(0,0,0,0.2)',
        }}
      >
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div
              style={{
                width: 30,
                height: 30,
                background: C.accent,
                borderRadius: 5,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: 14,
                color: '#fff',
                fontWeight: 700,
              }}
            >
              ⬡
            </div>
            <div>
              <div
                style={{
                  fontSize: 13,
                  color: '#fff',
                  fontWeight: 700,
                  letterSpacing: 1,
                }}
              >
                HX-CALC <span style={{ color: '#64b5f6' }}>EPC</span>
              </div>
              <div
                style={{ fontSize: 8, color: '#90a4ae', letterSpacing: 1.5 }}
              >
                PROFESSIONAL SHELL & TUBE HEAT EXCHANGER DESIGN
              </div>
            </div>
          </div>
          <div
            style={{
              width: 1,
              height: 26,
              background: 'rgba(255,255,255,0.15)',
            }}
          />
          <div style={{ display: 'flex', gap: 6, fontSize: 8.5 }}>
            {[
              'KERN+BELL-DELAWARE',
              'ASME SEC.VIII',
              `TEMA ${temaClass.split('—')[0].trim()}`,
              api660 === 'Yes' ? 'API 660 ✓' : 'API 660',
            ].map((m) => (
              <span
                key={m}
                style={{
                  color: '#64b5f6',
                  fontWeight: 600,
                  background: 'rgba(100,181,246,0.1)',
                  padding: '2px 6px',
                  borderRadius: 3,
                }}
              >
                {m}
              </span>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {r && (
            <>
              <span
                style={{
                  background: C.accent,
                  color: '#fff',
                  padding: '2px 8px',
                  borderRadius: 3,
                  fontFamily: 'monospace',
                  fontSize: 10,
                }}
              >
                TEMA: {r.temaDesig}
              </span>
              <span
                style={{
                  background: 'rgba(240,165,0,0.2)',
                  color: '#ffd54f',
                  padding: '2px 8px',
                  borderRadius: 3,
                  fontFamily: 'monospace',
                  fontSize: 10,
                }}
              >
                A={r.A_req} m²
              </span>
              <span
                style={{
                  background: 'rgba(255,255,255,0.08)',
                  color: '#fff',
                  padding: '2px 8px',
                  borderRadius: 3,
                  fontFamily: 'monospace',
                  fontSize: 10,
                }}
              >
                Q={r.Q} kW
              </span>
              <span
                style={{
                  background: 'rgba(255,255,255,0.08)',
                  color: '#fff',
                  padding: '2px 8px',
                  borderRadius: 3,
                  fontFamily: 'monospace',
                  fontSize: 10,
                }}
              >
                Nt={r.Nt}
              </span>
            </>
          )}
          <span style={{ color: '#90a4ae', fontSize: 10 }}>
            {eqTag} | {projName}
          </span>
        </div>
      </div>

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* LEFT PANEL */}
        <div
          className="no-print"
          style={{
            width: 272,
            borderRight: `1px solid ${C.border}`,
            background: C.panel,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
            boxShadow: '2px 0 4px rgba(0,0,0,0.04)',
          }}
        >
          <div
            style={{
              display: 'flex',
              borderBottom: `1px solid ${C.border}`,
              background: C.tabBg,
              flexShrink: 0,
              overflowX: 'auto',
            }}
          >
            {LB('process', 'PROCESS')}
            {LB('opcase', 'OP.CASES')}
            {LB('geometry', 'GEOMETRY')}
            {LB('mechanical', 'MECHANICAL')}
            {LB('nozzles', 'NOZZLES')}
            {LB('constraints', 'LIMITS')}
            {LB('project', 'PROJECT')}
          </div>
          <div style={{ flex: 1, overflowY: 'auto', padding: '10px 10px' }}>
            {lTab === 'process' && (
              <>
                <SH t="Hot Side" />
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    marginBottom: 8,
                  }}
                >
                  <input
                    type="checkbox"
                    checked={useCustomH}
                    onChange={(e) => setUseCustomH(e.target.checked)}
                  />
                  <label
                    style={{
                      fontSize: 10,
                      color: C.textMid,
                      cursor: 'pointer',
                    }}
                  >
                    Custom fluid properties
                  </label>
                </div>
                {!useCustomH ? (
                  <F
                    label="Fluid"
                    value={hFluid}
                    onChange={sHF}
                    options={Object.keys(CP)}
                  />
                ) : (
                  <>
                    <div
                      style={{
                        background: C.accentLt,
                        borderRadius: 4,
                        padding: '6px 8px',
                        marginBottom: 8,
                        fontSize: 9,
                        color: C.accent,
                        fontWeight: 600,
                      }}
                    >
                      CUSTOM HOT FLUID
                    </div>
                    <F
                      label="Density"
                      value={cRho_h}
                      onChange={setCRho_h}
                      unit="kg/m³"
                    />
                    <F
                      label="Viscosity"
                      value={cMu_h}
                      onChange={setCMu_h}
                      unit="mPa·s"
                    />
                    <F
                      label="Specific Heat"
                      value={cCp_h}
                      onChange={setCCp_h}
                      unit="kJ/kg·K"
                    />
                    <F
                      label="Thermal Conductivity"
                      value={cK_h}
                      onChange={setCK_h}
                      unit="W/m·K"
                    />
                  </>
                )}
                <F
                  label="Phase"
                  value={hPhase}
                  onChange={sHP}
                  options={FLUID_PHASE}
                />
                {[
                  'Two-Phase (Condensing)',
                  'Two-Phase (Vaporizing)',
                  'Steam Condensing',
                ].includes(hPhase) && (
                  <>
                    <F
                      label="Vapor Fraction In"
                      value={hVapFrac}
                      onChange={sHVF}
                      unit="—"
                    />
                    <F
                      label="Dew/Bubble Point"
                      value={hDewPt}
                      onChange={sHDew}
                      unit="°C"
                      text
                    />
                  </>
                )}
                <F label="Inlet Temp" value={hTin} onChange={sHTi} unit="°C" />
                <F
                  label="Outlet Temp"
                  value={hTout}
                  onChange={sHTo}
                  unit="°C"
                />
                <F
                  label="Mass Flow Rate"
                  value={hFlow}
                  onChange={sHFl}
                  unit="kg/s"
                />
                <F
                  label="Operating Pressure"
                  value={hOpP}
                  onChange={sHOpP}
                  unit="bar g"
                />
                <F
                  label="Design Pressure"
                  value={hDesP}
                  onChange={sHDP}
                  unit="bar g"
                />
                <F
                  label="Design Temperature"
                  value={hDesT}
                  onChange={sHDT}
                  unit="°C"
                />
                <F
                  label="Fouling Factor"
                  value={hFoul}
                  onChange={sHFo}
                  options={Object.keys(FOULING)}
                />
                <div
                  style={{
                    borderTop: `1px solid ${C.border}`,
                    margin: '8px 0',
                  }}
                />
                <SH t="Cold Side" />
                <div
                  style={{
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6,
                    marginBottom: 8,
                  }}
                >
                  <input
                    type="checkbox"
                    checked={useCustomC}
                    onChange={(e) => setUseCustomC(e.target.checked)}
                  />
                  <label
                    style={{
                      fontSize: 10,
                      color: C.textMid,
                      cursor: 'pointer',
                    }}
                  >
                    Custom fluid properties
                  </label>
                </div>
                {!useCustomC ? (
                  <F
                    label="Fluid"
                    value={cFluid}
                    onChange={sCF}
                    options={Object.keys(CP)}
                  />
                ) : (
                  <>
                    <div
                      style={{
                        background: C.accentLt,
                        borderRadius: 4,
                        padding: '6px 8px',
                        marginBottom: 8,
                        fontSize: 9,
                        color: C.accent,
                        fontWeight: 600,
                      }}
                    >
                      CUSTOM COLD FLUID
                    </div>
                    <F
                      label="Density"
                      value={cRho_c}
                      onChange={setCRho_c}
                      unit="kg/m³"
                    />
                    <F
                      label="Viscosity"
                      value={cMu_c}
                      onChange={setCMu_c}
                      unit="mPa·s"
                    />
                    <F
                      label="Specific Heat"
                      value={cCp_c}
                      onChange={setCCp_c}
                      unit="kJ/kg·K"
                    />
                    <F
                      label="Thermal Conductivity"
                      value={cK_c}
                      onChange={setCK_c}
                      unit="W/m·K"
                    />
                  </>
                )}
                <F
                  label="Phase"
                  value={cPhase}
                  onChange={sCP}
                  options={FLUID_PHASE}
                />
                <F label="Inlet Temp" value={cTin} onChange={sCTi} unit="°C" />
                <F
                  label="Outlet Temp"
                  value={cTout}
                  onChange={sCTo}
                  unit="°C"
                />
                <F
                  label="Operating Pressure"
                  value={cOpP}
                  onChange={sCOpP}
                  unit="bar g"
                />
                <F
                  label="Design Pressure"
                  value={cDesP}
                  onChange={sCDP}
                  unit="bar g"
                />
                <F
                  label="Design Temperature"
                  value={cDesT}
                  onChange={sCDT}
                  unit="°C"
                />
                <F
                  label="Fouling Factor"
                  value={cFoul}
                  onChange={sCFo}
                  options={Object.keys(FOULING)}
                />
              </>
            )}

            {lTab === 'opcase' && (
              <>
                <SH t="Start-Up Case" c={C.warning} />
                <F
                  label="Shell Max Pressure"
                  value={hPstart}
                  onChange={sHPs}
                  unit="bar g"
                />
                <F
                  label="Shell Max Temperature"
                  value={hTstart}
                  onChange={sHTs}
                  unit="°C"
                />
                <div
                  style={{
                    borderTop: `1px solid ${C.border}`,
                    margin: '8px 0',
                  }}
                />
                <SH t="Upset / Worst Case" c={C.danger} />
                <F
                  label="Shell Max Pressure"
                  value={hPupset}
                  onChange={sHPu}
                  unit="bar g"
                />
                <F
                  label="Shell Max Temperature"
                  value={hTupset}
                  onChange={sHTu}
                  unit="°C"
                />
                <div
                  style={{
                    borderTop: `1px solid ${C.border}`,
                    margin: '8px 0',
                  }}
                />
                <SH t="Steamout Condition" />
                <F
                  label="Steamout Pressure"
                  value={hSteamP}
                  onChange={sHSP}
                  unit="bar g"
                  hint="Typically 3.5 bar g"
                />
                <F
                  label="Steamout Temperature"
                  value={hSteamT}
                  onChange={sHST}
                  unit="°C"
                  hint="Typically 150°C"
                />
                <div
                  style={{
                    background: C.warningLt,
                    borderRadius: 4,
                    padding: 8,
                    marginTop: 8,
                    fontSize: 9,
                    color: C.warning,
                    lineHeight: 1.7,
                    border: `1px solid ${C.warning}`,
                  }}
                >
                  Steamout condition is used for maintenance cleaning. Shell
                  must be designed to withstand full steamout P&T.
                </div>
              </>
            )}

            {lTab === 'geometry' && (
              <>
                <F
                  label="Front Head Type"
                  value={frontHead}
                  onChange={sFH}
                  options={Object.keys(FRONT_HEAD)}
                />
                <div
                  style={{
                    background: C.accentLt,
                    borderRadius: 3,
                    padding: '4px 8px',
                    marginBottom: 8,
                    fontSize: 9,
                    color: C.accent,
                  }}
                >
                  {FRONT_HEAD[frontHead]?.desc}
                </div>
                <F
                  label="Shell Type"
                  value={shellType}
                  onChange={sST}
                  options={Object.keys(SHELL_TYPES)}
                />
                <div
                  style={{
                    background: C.accentLt,
                    borderRadius: 3,
                    padding: '4px 8px',
                    marginBottom: 8,
                    fontSize: 9,
                    color: C.accent,
                  }}
                >
                  {SHELL_TYPES[shellType]?.desc}
                </div>
                <F
                  label="Bundle / Rear Head"
                  value={bundleType}
                  onChange={sBT}
                  options={Object.keys(BUNDLE_TYPES)}
                />
                <div
                  style={{
                    background: C.accentLt,
                    borderRadius: 3,
                    padding: '4px 8px',
                    marginBottom: 8,
                    fontSize: 9,
                    color: C.accent,
                  }}
                >
                  {BUNDLE_TYPES[bundleType]?.desc}
                </div>
                <F
                  label="TEMA Class"
                  value={temaClass}
                  onChange={sTC}
                  options={Object.keys(TEMA_CLASS)}
                />
                <F
                  label="Tube Passes"
                  value={tubePasses}
                  onChange={(v: any) => sTP(+v)}
                  options={[1, 2, 4, 6, 8]}
                />
                <F
                  label="Tube OD"
                  value={tubeODK}
                  onChange={sTOD}
                  options={Object.keys(TUBE_OD_MAP)}
                />
                <F
                  label="Wall Thickness"
                  value={tubeThk}
                  onChange={sTTh}
                  unit="mm"
                  hint="BWG14=2.11 | BWG16=1.65"
                />
                <F
                  label="Tube Length"
                  value={tubeLen}
                  onChange={sTL}
                  unit="m"
                  hint="Std: 1.83/2.44/3.66/4.88/6.10m"
                />
                <F
                  label="Pitch & Layout"
                  value={pitchK}
                  onChange={sPK}
                  options={Object.keys(PITCH_MAP)}
                />
                <F
                  label="Tube-to-TS Joint"
                  value={tubeTSJoint}
                  onChange={sTTSJ}
                  options={TUBE_TS}
                />
                <F
                  label="Baffle Spacing"
                  value={baffleSpacing}
                  onChange={sBS}
                  unit="mm"
                />
                <F
                  label="Inlet Baffle Spacing"
                  value={inletBaffle}
                  onChange={sIB}
                  unit="mm"
                />
                <F
                  label="Baffle Cut"
                  value={baffleCut}
                  onChange={sBC}
                  unit="%"
                  hint="15–35%. Standard: 25%"
                />
                <F
                  label="Bypass Seal"
                  value={bypassSeal}
                  onChange={sBPS}
                  options={BYPASS_SEAL}
                />
                <F
                  label="Impingement Protection"
                  value={impingement}
                  onChange={sImp}
                  options={IMPINGEMENT}
                />
              </>
            )}

            {lTab === 'mechanical' && (
              <>
                <F
                  label="Shell Material"
                  value={matShell}
                  onChange={sMSh}
                  options={Object.keys(MATERIALS)}
                />
                <F
                  label="Tube Material"
                  value={matTube}
                  onChange={sMTu}
                  options={Object.keys(MATERIALS)}
                />
                <F
                  label="Gasket Material"
                  value={matGasket}
                  onChange={sMG}
                  options={GASKETS}
                />
                <F
                  label="Fastener Material"
                  value={matFastener}
                  onChange={sMF}
                  options={FASTENERS}
                />
                <F
                  label="Spare Gasket Sets"
                  value={spareGaskets}
                  onChange={sSG}
                  unit="sets"
                />
                <F
                  label="Joint Efficiency (E)"
                  value={jointEff}
                  onChange={sJE}
                  options={[1.0, 0.85, 0.7]}
                  hint="1.0=Full RT | 0.85=Spot | 0.7=None"
                />
                <F
                  label="Orientation"
                  value={orientation}
                  onChange={sOR}
                  options={ORIENTATION_OPT}
                />
                <F label="No. of Saddles" value={numSaddles} onChange={sNS} />
                <F
                  label="Insulation"
                  value={insulReq}
                  onChange={sIR}
                  options={['Yes', 'No']}
                />
                {insulReq === 'Yes' && (
                  <F
                    label="Insulation Thickness"
                    value={insulThk}
                    onChange={sIT}
                    unit="mm"
                  />
                )}
                <F
                  label="Surface Finish"
                  value={surfFinish}
                  onChange={sSF}
                  options={SURFACE_FINISH}
                />
                <F
                  label="Paint / Coating"
                  value={paintSpec}
                  onChange={sPSp}
                  options={PAINT_SPEC}
                />
                <F
                  label="Shipping Condition"
                  value={shipCond}
                  onChange={sSC}
                  options={SHIP_COND}
                />
                <F
                  label="ASME U-Stamp"
                  value={uStamp}
                  onChange={sUS}
                  options={['Yes', 'No']}
                />
                <F
                  label="API 660"
                  value={api660}
                  onChange={sAPI}
                  options={['Yes', 'No']}
                />
                <F
                  label="Nameplate"
                  value={nameplate}
                  onChange={sNP}
                  options={NAMEPLATE}
                />
              </>
            )}

            {lTab === 'nozzles' && (
              <>
                <SH t="Shell Side (Hot)" c={C.danger} />
                {(
                  [
                    [
                      'Shell Inlet',
                      'N1',
                      hInN,
                      sHIN,
                      hInSch,
                      sHIS,
                      hInLine,
                      sHIL,
                    ],
                    [
                      'Shell Outlet',
                      'N2',
                      hOutN,
                      sHON,
                      hOutSch,
                      sHOS,
                      hOutLine,
                      sHOL,
                    ],
                  ] as any[]
                ).map(
                  ([svc, tag, sz, setSz, sch, setSch, line, setLine]: any) => (
                    <div
                      key={tag}
                      style={{
                        background: C.dangerLt,
                        borderRadius: 4,
                        padding: 8,
                        marginBottom: 8,
                        border: `1px solid #f5b7b1`,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 9,
                          color: C.danger,
                          fontWeight: 700,
                          marginBottom: 5,
                        }}
                      >
                        {tag} — {svc}
                      </div>
                      <F
                        label="Size"
                        value={sz}
                        onChange={setSz}
                        options={NOZZLE_SIZES}
                      />
                      <F
                        label="Schedule"
                        value={sch}
                        onChange={setSch}
                        options={PIPE_SCHED}
                      />
                      <F
                        label="P&ID Line No."
                        value={line}
                        onChange={setLine}
                        text
                      />
                    </div>
                  )
                )}
                <SH t="Tube Side (Cold)" />
                {(
                  [
                    [
                      'Tube Inlet',
                      'N3',
                      cInN,
                      sCIN,
                      cInSch,
                      sCIS,
                      cInLine,
                      sCIL,
                    ],
                    [
                      'Tube Outlet',
                      'N4',
                      cOutN,
                      sCON,
                      cOutSch,
                      sCOS,
                      cOutLine,
                      sCOL,
                    ],
                  ] as any[]
                ).map(
                  ([svc, tag, sz, setSz, sch, setSch, line, setLine]: any) => (
                    <div
                      key={tag}
                      style={{
                        background: C.accentLt,
                        borderRadius: 4,
                        padding: 8,
                        marginBottom: 8,
                        border: `1px solid #b3d4f5`,
                      }}
                    >
                      <div
                        style={{
                          fontSize: 9,
                          color: C.accent,
                          fontWeight: 700,
                          marginBottom: 5,
                        }}
                      >
                        {tag} — {svc}
                      </div>
                      <F
                        label="Size"
                        value={sz}
                        onChange={setSz}
                        options={NOZZLE_SIZES}
                      />
                      <F
                        label="Schedule"
                        value={sch}
                        onChange={setSch}
                        options={PIPE_SCHED}
                      />
                      <F
                        label="P&ID Line No."
                        value={line}
                        onChange={setLine}
                        text
                      />
                    </div>
                  )
                )}
                <SH t="Utility Nozzles" />
                <F
                  label="Vent (N5)"
                  value={ventN}
                  onChange={sVN}
                  options={NOZZLE_SIZES}
                />
                <F
                  label="Drain (N6)"
                  value={drainN}
                  onChange={sDN}
                  options={NOZZLE_SIZES}
                />
                <F
                  label="Flange Class"
                  value={flangeClass}
                  onChange={sFC}
                  options={FLANGE_CLASS}
                />
                <F
                  label="Flange Face"
                  value={flangeFace}
                  onChange={sFF}
                  options={FLANGE_FACE}
                />
              </>
            )}

            {lTab === 'constraints' && (
              <>
                <SH t="Client Constraint Parameters" c={C.purple} />
                <div
                  style={{
                    background: C.purpleLt,
                    borderRadius: 4,
                    padding: 8,
                    marginBottom: 10,
                    fontSize: 9,
                    color: C.purple,
                    lineHeight: 1.6,
                  }}
                >
                  Enter client-specified limits. Tool checks design against each
                  constraint and flags violations. Leave as 0 to skip.
                </div>
                <F
                  label="Max Heat Transfer Area"
                  value={maxArea}
                  onChange={setMaxArea}
                  unit="m²"
                  hint="Maximum area allowed (plot space, weight limit)"
                />
                <F
                  label="Min Heat Transfer Area"
                  value={minArea}
                  onChange={setMinArea}
                  unit="m²"
                  hint="Minimum area required (future capacity)"
                />
                <F
                  label="Max Shell Side ΔP"
                  value={maxDPs}
                  onChange={setMaxDPs}
                  unit="kPa"
                  hint="Client MAPD shell side"
                />
                <F
                  label="Max Tube Side ΔP"
                  value={maxDPt}
                  onChange={setMaxDPt}
                  unit="kPa"
                  hint="Client MAPD tube side"
                />
                <F
                  label="Max Shell Diameter"
                  value={maxDs}
                  onChange={setMaxDs}
                  unit="mm"
                  hint="Plot space or transport limit"
                />
                <F
                  label="Max Overdesign"
                  value={maxOverdesign}
                  onChange={setMaxOverdesign}
                  unit="%"
                  hint="Typically 35% max"
                />
                <div
                  style={{
                    borderTop: `1px solid ${C.border}`,
                    margin: '8px 0',
                  }}
                />
                {constraintResults.length > 0 ? (
                  <>
                    <SH t="Constraint Check Results" c={C.purple} />
                    {constraintResults.map((c: any, i: number) => (
                      <div
                        key={i}
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 8,
                          padding: '5px 6px',
                          marginBottom: 4,
                          background: c.ok ? C.successLt : C.dangerLt,
                          borderRadius: 3,
                          border: `1px solid ${c.ok ? C.success : C.danger}`,
                        }}
                      >
                        <span style={{ fontSize: 12 }}>{c.ok ? '✓' : '✗'}</span>
                        <div style={{ flex: 1 }}>
                          <div
                            style={{
                              fontSize: 9,
                              fontWeight: 700,
                              color: c.ok ? C.success : C.danger,
                            }}
                          >
                            {c.name}
                          </div>
                          <div style={{ fontSize: 8, color: C.textMid }}>
                            {c.val} | Limit: {c.limit}
                          </div>
                        </div>
                      </div>
                    ))}
                  </>
                ) : (
                  <div
                    style={{
                      fontSize: 9,
                      color: C.textDim,
                      padding: 8,
                      background: C.panelAlt,
                      borderRadius: 4,
                    }}
                  >
                    No constraints set yet.
                  </div>
                )}
              </>
            )}

            {lTab === 'project' && (
              <>
                <SH t="Project" />
                <F label="Project Name" value={projName} onChange={sPRN} text />
                <F
                  label="Plant / Location"
                  value={plantLoc}
                  onChange={sPL}
                  text
                />
                <F label="Client" value={client} onChange={sCL} text />
                <F label="Equipment Tag" value={eqTag} onChange={sET} text />
                <F label="Document Number" value={docNo} onChange={sDN2} text />
                <F label="Revision" value={revNo} onChange={sRN} text />
                <F
                  label="Revision Description"
                  value={revDesc}
                  onChange={sRD}
                  text
                />
                <F label="Prepared By" value={prepBy} onChange={sPB} text />
                <F label="Checked By" value={chkBy} onChange={sCB} text />
                <F label="Approved By" value={appBy} onChange={sAB} text />
              </>
            )}
          </div>
        </div>

        {/* RIGHT PANEL */}
        <div
          style={{
            flex: 1,
            display: 'flex',
            flexDirection: 'column',
            overflow: 'hidden',
          }}
        >
          <div
            className="no-print"
            style={{
              display: 'flex',
              borderBottom: `1px solid ${C.border}`,
              background: C.panel,
              flexShrink: 0,
              overflowX: 'auto',
              boxShadow: '0 2px 4px rgba(0,0,0,0.04)',
            }}
          >
            {RB('thermal', 'THERMAL')}
            {RB('hydraulic', 'HYDRAULIC')}
            {RB('mechanical', 'MECHANICAL')}
            {RB('tubecount', 'TUBE COUNT')}
            {RB('selector', 'HX SELECTOR')}
            {RB('fouling', 'FOULING')}
            {RB('flowstudy', 'FLOW STUDY')}
            {RB('shellcomp', 'SHELL COMP.')}
            {RB('checks', 'CHECKS')}
            {RB('datasheet', 'DATASHEET')}
          </div>
          <div style={{ flex: 1, overflowY: 'auto', background: C.bg }}>
            {!r && (
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  height: '100%',
                  flexDirection: 'column',
                  gap: 10,
                }}
              >
                <div style={{ fontSize: 40, opacity: 0.12 }}>⬡</div>
                <div style={{ color: C.textDim, fontSize: 12 }}>
                  Enter valid process conditions to calculate
                </div>
                <div style={{ color: C.danger, fontSize: 10 }}>
                  Hot outlet must be above cold inlet temperature
                </div>
              </div>
            )}

            {r && rTab === 'thermal' && (
              <>
                <div style={{ padding: 14 }}>
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(4,1fr)',
                      gap: 10,
                      marginBottom: 14,
                    }}
                  >
                    {[
                      { l: 'Heat Duty', v: `${r.Q} kW`, ok: true },
                      { l: 'Area Required', v: `${r.A_req} m²`, ok: true },
                      { l: 'TEMA Designation', v: r.temaDesig, ok: true },
                      {
                        l: 'Ft Factor',
                        v: r.Ft,
                        ok: parseFloat(r.Ft) >= 0.85,
                        w: parseFloat(r.Ft) < 0.75,
                      },
                    ].map(({ l, v, ok, w }: any) => (
                      <div
                        key={l}
                        style={{
                          background:
                            ok && !w ? C.successLt : w ? C.dangerLt : C.panel,
                          borderRadius: 8,
                          padding: '12px 14px',
                          border: `1px solid ${
                            ok && !w ? '#a8d5c2' : w ? '#f5b7b1' : C.border
                          }`,
                        }}
                      >
                        <div
                          style={{
                            fontSize: 9,
                            color: C.textDim,
                            marginBottom: 3,
                            textTransform: 'uppercase' as const,
                            letterSpacing: 0.8,
                          }}
                        >
                          {l}
                        </div>
                        <div
                          style={{
                            fontSize: 18,
                            fontWeight: 700,
                            color: ok && !w ? C.success : w ? C.danger : C.text,
                            fontFamily: 'monospace',
                          }}
                        >
                          {v}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
                <SH t="Heat Duty" />
                <RW k="Total Heat Duty" v={r.Q} u="kW" hi bold />
                <RW k="Heat Duty" v={r.Q_MW} u="MW" />
                <RW k="Cold Side Required Flow" v={r.mc} u="kg/s" />
                <SH t="LMTD Analysis" />
                <RW k="LMTD (Uncorrected)" v={r.lmtd} u="°C" />
                <RW k="R — Heat Capacity Ratio" v={r.R} />
                <RW k="S — Effectiveness Factor" v={r.S} />
                <RW
                  k="Ft Correction Factor"
                  v={r.Ft}
                  hi={parseFloat(r.Ft) >= 0.85}
                  warn={parseFloat(r.Ft) < 0.75}
                />
                <RW k="Corrected Effective LMTD" v={r.eff_lmtd} u="°C" hi />
                <SH t="Heat Transfer Coefficients" />
                <RW k="U Overall — Clean" v={r.U_cl} u="W/m²·K" />
                <RW k="U Overall — Dirty (Design)" v={r.U_dir} u="W/m²·K" hi />
                <RW k="Film Coeff Shell (hs)" v={r.hs} u="W/m²·K" />
                <RW k="Film Coeff Tube (ht)" v={r.ht} u="W/m²·K" />
                <RW
                  k="Overdesign (fouling basis)"
                  v={`${r.overdesign}%`}
                  hi={
                    parseFloat(r.overdesign) >= 10 &&
                    parseFloat(r.overdesign) <= 35
                  }
                  warn={parseFloat(r.overdesign) > 40}
                />
                <SH t="Sizing Results" />
                <RW k="Required Heat Transfer Area" v={r.A_req} u="m²" hi />
                <RW k="Actual Area (with Nt rounded)" v={r.A_actual} u="m²" />
                <RW
                  k="Actual Overdesign"
                  v={`${r.overdesign_actual}%`}
                  hi={
                    parseFloat(r.overdesign_actual) >= 10 &&
                    parseFloat(r.overdesign_actual) <= 35
                  }
                />
                <RW k="NTU" v={r.NTU} />
                <RW
                  k="Thermal Effectiveness"
                  v={`${r.eff}%`}
                  hi={parseFloat(r.eff) > 70}
                />
                <RW k="Shells Required" v={r.shells} />
              </>
            )}

            {r && rTab === 'hydraulic' && (
              <>
                <SH t="Tube Side (Cold Fluid)" />
                <RW
                  k="Tube Velocity"
                  v={r.vt}
                  u="m/s"
                  hi={!r.warn_vt}
                  warn={r.warn_vt}
                />
                <RW k="  Acceptable: 0.5–3.0 m/s" v="" sub />
                <RW k="Reynolds Number" v={r.Re_t} />
                <RW k="Prandtl Number" v={r.Pr_t} />
                <RW
                  k="Flow Regime"
                  v={r.flow_t}
                  hi={r.flow_t.includes('✓')}
                  warn={r.flow_t.includes('✗')}
                />
                <RW
                  k="Tube Side ΔP"
                  v={r.dPt}
                  u="kPa"
                  hi={!r.warn_dPt}
                  warn={r.warn_dPt}
                />
                <SH t="Shell Side (Hot Fluid)" />
                <RW
                  k="Shell Velocity"
                  v={r.vs}
                  u="m/s"
                  hi={!r.warn_vs}
                  warn={r.warn_vs}
                />
                <RW k="  Acceptable: 0.3–1.5 m/s" v="" sub />
                <RW k="Reynolds Number" v={r.Re_s} />
                <RW k="Prandtl Number" v={r.Pr_s} />
                <RW k="Flow Regime" v={r.flow_s} hi={r.flow_s.includes('✓')} />
                <RW
                  k="Shell Side ΔP"
                  v={r.dPs}
                  u="kPa"
                  hi={!r.warn_dPs}
                  warn={r.warn_dPs}
                />
                <RW k="No. of Baffles" v={r.Nb} />
                <RW k="Baffle Spacing" v={r.Bs_mm} u="mm" />
                <SH t="ρV² Impingement Checks (TEMA)" />
                <RW
                  k="Shell Nozzle ρV² (Inlet)"
                  v={r.rv2_hin}
                  u="kg/m·s²"
                  hi={parseFloat(r.rv2_hin) <= r.imp_limit}
                  warn={r.warn_rv2_h}
                />
                <RW k={`  TEMA Limit (${hPhase})`} v={r.imp_limit} sub />
                <RW k="Bundle Entrance ρV²" v={r.rv2_bundle} u="kg/m·s²" />
                <RW
                  k="Impingement Protection"
                  v={r.imp_req ? 'REQUIRED' : 'NOT Required'}
                  warn={r.imp_req}
                  hi={!r.imp_req}
                />
              </>
            )}

            {r && rTab === 'mechanical' && (
              <>
                <SH t="Tube Bundle" />
                <RW k="Total Tubes" v={r.Nt} hi bold />
                <RW k="Tubes per Pass" v={r.Ntp} />
                <RW k="Tube OD / ID" v={`${r.OD_mm} / ${r.ID_mm}`} u="mm" />
                <RW k="Tube Length" v={r.L} u="m" />
                <RW k="Pitch" v={pitchK} />
                <SH t="Shell" />
                <RW k="TEMA Designation" v={r.temaDesig} hi />
                <RW k="Shell ID (estimated)" v={r.Ds_mm} u="mm" />
                <RW k="Shell Wall Thickness (ASME)" v={r.t_sh} u="mm" />
                <RW k="Allowable Stress" v={r.Sm} u="MPa" />
                <RW k="Joint Efficiency" v={r.E} />
                <RW k="Corrosion Allowance" v={r.ca} u="mm" />
                <RW k="Hydrotest — Shell" v={r.P_test_sh} u="bar g" />
                <RW k="Hydrotest — Tube" v={r.P_test_tu} u="bar g" />
                <SH t="Weights" />
                <RW
                  k="Empty Weight"
                  v={`${r.W_empty.toLocaleString()}`}
                  u="kg"
                />
                <RW
                  k="Operating Weight"
                  v={`${r.W_oper.toLocaleString()}`}
                  u="kg"
                  hi
                />
                <RW
                  k="Hydrotest Weight"
                  v={`${r.W_hydro.toLocaleString()}`}
                  u="kg"
                />
                <SH t="Cost" />
                <RW k="Estimated Cost" v={`USD ${r.cost}`} hi />
              </>
            )}

            {r && rTab === 'tubecount' && (
              <>
                <div style={{ padding: '10px 12px 4px' }}>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: C.text,
                      marginBottom: 2,
                    }}
                  >
                    Step-by-Step Tube Count Calculation
                  </div>
                  <div
                    style={{ fontSize: 9, color: C.textDim, marginBottom: 8 }}
                  >
                    Complete derivation from required area to final tube count
                  </div>
                </div>
                <SH t="Step 1 — Required Heat Transfer Area" />
                <RW k="Heat Duty Q" v={r.Q} u="kW" />
                <RW k="U Dirty (Design)" v={r.U_dir} u="W/m²·K" />
                <RW k="Corrected LMTD" v={r.eff_lmtd} u="°C" />
                <RW k="Formula: A = Q×1000 / (U × LMTD × Ft)" v="" />
                <RW k="A_required" v={r.A_req} u="m²" hi bold />
                <SH t="Step 2 — Area Per Tube" />
                <RW k="Tube OD" v={r.OD_mm} u="mm" />
                <RW k="Tube Length" v={r.L} u="m" />
                <RW k="Formula: A_tube = π × OD × L" v="" />
                <RW k="Area per tube" v={r.A_per_tube} u="m²" hi />
                <SH t="Step 3 — Calculated Tube Count" />
                <RW k="Formula: Nt_calc = A_req / A_per_tube" v="" />
                <RW
                  k={`Nt_calc = ${r.A_req} / ${r.A_per_tube}`}
                  v={r.Nt_calc}
                  u="tubes (before rounding)"
                />
                <RW
                  k="Nt (rounded up to whole number)"
                  v={r.Nt}
                  u="tubes"
                  hi
                  bold
                />
                <RW k="Tubes per Pass" v={r.Ntp} u="tubes/pass" />
                <SH t="Step 4 — Actual Area After Rounding" />
                <RW k="Formula: A_actual = Nt × A_per_tube" v="" />
                <RW
                  k={`A_actual = ${r.Nt} × ${r.A_per_tube}`}
                  v={r.A_actual}
                  u="m²"
                />
                <RW k="Required Area" v={r.A_req} u="m²" />
                <RW
                  k="Actual Overdesign (geometry)"
                  v={`${r.overdesign_actual}%`}
                  hi={
                    parseFloat(r.overdesign_actual) >= 0 &&
                    parseFloat(r.overdesign_actual) <= 40
                  }
                />
                <SH t="Step 5 — Shell Diameter from Tube Count" />
                <RW
                  k="Formula: Ds = 0.637 × √(Cl/CTP) × √(Nt × p² / 0.785)"
                  v=""
                />
                <RW k="Pitch Layout Factor Cl" v={PITCH_MAP[pitchK]?.Cl} />
                <RW
                  k="CTP (tube count constant)"
                  v={+tubePasses === 1 ? 0.93 : +tubePasses === 2 ? 0.9 : 0.85}
                />
                <RW
                  k="Tube Pitch p"
                  v={(PITCH_MAP[pitchK]?.p * 1000).toFixed(0)}
                  u="mm"
                />
                <RW k="Estimated Shell ID" v={r.Ds_mm} u="mm" hi bold />
                <SH t="Summary" />
                <div
                  style={{
                    margin: '8px 12px',
                    padding: 10,
                    background: C.accentLt,
                    borderRadius: 6,
                    fontSize: 10,
                    color: C.textMid,
                    lineHeight: 2.2,
                    border: `1px solid ${C.accent}`,
                  }}
                >
                  <b style={{ color: C.text }}>Final Answer:</b>
                  <br />
                  Total Tubes: <b style={{ color: C.accent }}>{r.Nt}</b> (
                  {r.Ntp} per pass × {tubePasses} passes)
                  <br />
                  Actual Area:{' '}
                  <b style={{ color: C.accent }}>{r.A_actual} m²</b> vs Required{' '}
                  {r.A_req} m²
                  <br />
                  Overdesign:{' '}
                  <b style={{ color: C.success }}>
                    {r.overdesign_actual}%
                  </b>{' '}
                  (due to tube rounding)
                  <br />
                  Shell ID: <b style={{ color: C.accent }}>{r.Ds_mm} mm</b>
                </div>
              </>
            )}

            {r && rTab === 'selector' && (
              <>
                <div style={{ padding: '10px 12px 4px' }}>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: C.text,
                      marginBottom: 2,
                    }}
                  >
                    HX Type Selector — Smart Recommendation
                  </div>
                  <div
                    style={{ fontSize: 9, color: C.textDim, marginBottom: 6 }}
                  >
                    Based on your process conditions: ΔT=
                    {r.dT_shell_tube.toFixed(0)}°C, Fouling=
                    {r.is_fouling ? 'HIGH' : 'LOW'}, Pressure=
                    {r.is_high_pressure ? 'HIGH' : 'NORMAL'}
                  </div>
                </div>
                {hxRecs.map((rec: any, i: number) => (
                  <div
                    key={i}
                    style={{
                      margin: '0 12px 10px',
                      borderRadius: 8,
                      border: `2px solid ${
                        i === 0 ? C.accent : rec.suitable ? C.success : C.border
                      }`,
                      overflow: 'hidden',
                    }}
                  >
                    <div
                      style={{
                        background:
                          i === 0
                            ? C.accent
                            : rec.suitable
                            ? C.success
                            : C.textDim,
                        padding: '8px 12px',
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                      }}
                    >
                      <div
                        style={{ fontSize: 10, fontWeight: 700, color: '#fff' }}
                      >
                        {rec.name}
                      </div>
                      <div
                        style={{
                          fontSize: 9,
                          color: 'rgba(255,255,255,0.85)',
                          background: 'rgba(0,0,0,0.2)',
                          padding: '2px 8px',
                          borderRadius: 3,
                        }}
                      >
                        {i === 0
                          ? '★ RECOMMENDED'
                          : rec.suitable
                          ? '✓ ACCEPTABLE'
                          : '✗ NOT SUITABLE'}
                      </div>
                    </div>
                    <div
                      style={{
                        padding: '10px 12px',
                        background:
                          i === 0
                            ? C.accentLt
                            : rec.suitable
                            ? C.successLt
                            : C.panelAlt,
                      }}
                    >
                      {rec.reasons.map((reason: string, j: number) => (
                        <div
                          key={j}
                          style={{
                            fontSize: 9,
                            color: C.success,
                            marginBottom: 4,
                            display: 'flex',
                            gap: 6,
                            alignItems: 'flex-start',
                          }}
                        >
                          <span
                            style={{
                              color: C.success,
                              fontWeight: 700,
                              flexShrink: 0,
                            }}
                          >
                            ✓
                          </span>
                          {reason}
                        </div>
                      ))}
                      {rec.warnings.map((w: string, j: number) => (
                        <div
                          key={j}
                          style={{
                            fontSize: 9,
                            color: C.warning,
                            marginBottom: 4,
                            display: 'flex',
                            gap: 6,
                            alignItems: 'flex-start',
                          }}
                        >
                          <span style={{ flexShrink: 0 }}>⚠</span>
                          {w}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
                <div
                  style={{
                    margin: '0 12px 12px',
                    padding: 10,
                    background: C.purpleLt,
                    borderRadius: 6,
                    border: `1px solid ${C.purple}`,
                    fontSize: 9,
                    color: C.purple,
                    lineHeight: 1.8,
                  }}
                >
                  <b>Shell Type Recommendation:</b>{' '}
                  {parseFloat(r.Ft) >= 0.85
                    ? 'E-Shell (single pass) is adequate — Ft=' + r.Ft
                    : parseFloat(r.Ft) >= 0.75
                    ? 'E-Shell marginal (Ft=' +
                      r.Ft +
                      ') — consider F-shell or add tube passes'
                    : '⚠ Ft=' +
                      r.Ft +
                      ' — F-shell or additional shells in series REQUIRED'}
                  <br />
                  <b>Ft Factor:</b> {r.Ft} —{' '}
                  {parseFloat(r.Ft) >= 0.85
                    ? 'Excellent'
                    : parseFloat(r.Ft) >= 0.75
                    ? 'Acceptable'
                    : 'FAIL — redesign required'}
                </div>
              </>
            )}

            {r && rTab === 'fouling' && (
              <>
                <div style={{ padding: '10px 12px 4px' }}>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: C.text,
                      marginBottom: 2,
                    }}
                  >
                    Fouling Performance Degradation Over Time
                  </div>
                  <div
                    style={{ fontSize: 9, color: C.textDim, marginBottom: 8 }}
                  >
                    How exchanger performance changes as fouling builds up.
                    Assumes linear fouling buildup over 18 months to full design
                    fouling factor.
                  </div>
                </div>
                <div style={{ padding: '0 12px 12px' }}>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 14,
                      border: `1px solid ${C.border}`,
                      marginBottom: 12,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        marginBottom: 8,
                        color: C.text,
                      }}
                    >
                      U Overall vs Time
                    </div>
                    <ResponsiveContainer width="100%" height={220}>
                      <LineChart
                        data={r.foulData}
                        margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={C.border}
                        />
                        <XAxis
                          dataKey="month"
                          label={{
                            value: 'Months in Service',
                            position: 'insideBottom',
                            offset: -3,
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          label={{
                            value: 'U (W/m²·K)',
                            angle: -90,
                            position: 'insideLeft',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <Tooltip
                          contentStyle={{
                            fontSize: 10,
                            background: C.panel,
                            border: `1px solid ${C.border}`,
                          }}
                        />
                        <ReferenceLine
                          y={parseFloat(r.U_dir)}
                          stroke={C.danger}
                          strokeDasharray="4 2"
                          label={{
                            value: 'Design U',
                            fontSize: 8,
                            fill: C.danger,
                          }}
                        />
                        <ReferenceLine
                          y={parseFloat(r.U_cl)}
                          stroke={C.success}
                          strokeDasharray="4 2"
                          label={{
                            value: 'Clean U',
                            fontSize: 8,
                            fill: C.success,
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="U"
                          stroke={C.accent}
                          strokeWidth={2.5}
                          dot={false}
                          name="U Overall (W/m²·K)"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 14,
                      border: `1px solid ${C.border}`,
                      marginBottom: 12,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        marginBottom: 8,
                        color: C.text,
                      }}
                    >
                      Duty Achievement & Outlet Temperature vs Time
                    </div>
                    <ResponsiveContainer width="100%" height={220}>
                      <LineChart
                        data={r.foulData}
                        margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={C.border}
                        />
                        <XAxis
                          dataKey="month"
                          label={{
                            value: 'Months in Service',
                            position: 'insideBottom',
                            offset: -3,
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          yAxisId="pct"
                          domain={[80, 115]}
                          label={{
                            value: 'Duty %',
                            angle: -90,
                            position: 'insideLeft',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          yAxisId="T"
                          orientation="right"
                          label={{
                            value: 'Tout (°C)',
                            angle: 90,
                            position: 'insideRight',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <Tooltip
                          contentStyle={{
                            fontSize: 10,
                            background: C.panel,
                            border: `1px solid ${C.border}`,
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: 9 }} />
                        <ReferenceLine
                          yAxisId="pct"
                          y={100}
                          stroke={C.accent}
                          strokeDasharray="4 2"
                        />
                        <ReferenceLine
                          yAxisId="pct"
                          y={90}
                          stroke={C.danger}
                          strokeDasharray="4 2"
                          label={{
                            value: '90% min',
                            fontSize: 8,
                            fill: C.danger,
                          }}
                        />
                        <Line
                          yAxisId="pct"
                          type="monotone"
                          dataKey="duty_pct"
                          stroke={C.success}
                          strokeWidth={2}
                          dot={false}
                          name="Duty %"
                        />
                        <Line
                          yAxisId="T"
                          type="monotone"
                          dataKey="Tout"
                          stroke={C.warning}
                          strokeWidth={2}
                          dot={false}
                          name="Hot Outlet T (°C)"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 12,
                      border: `1px solid ${C.border}`,
                    }}
                  >
                    <div
                      style={{
                        fontSize: 10,
                        fontWeight: 700,
                        marginBottom: 8,
                        color: C.text,
                      }}
                    >
                      Fouling Milestone Summary
                    </div>
                    <table
                      style={{
                        width: '100%',
                        borderCollapse: 'collapse',
                        fontSize: 9,
                      }}
                    >
                      <thead>
                        <tr style={{ background: C.header }}>
                          {[
                            'Month',
                            'U (W/m²·K)',
                            'Duty %',
                            'Hot Outlet °C',
                            'Status',
                          ].map((h) => (
                            <th
                              key={h}
                              style={{
                                padding: '5px 8px',
                                color: '#fff',
                                textAlign: 'left',
                                fontWeight: 600,
                              }}
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {r.foulData
                          .filter((_: any, i: number) => i % 3 === 0)
                          .map((d: any, i: number) => (
                            <tr
                              key={i}
                              style={{
                                background: d.clean_needed
                                  ? C.dangerLt
                                  : i % 2 === 0
                                  ? C.panel
                                  : C.panelAlt,
                              }}
                            >
                              <td
                                style={{ padding: '4px 8px', fontWeight: 600 }}
                              >
                                {d.month}
                              </td>
                              <td style={{ padding: '4px 8px' }}>{d.U}</td>
                              <td
                                style={{
                                  padding: '4px 8px',
                                  color:
                                    d.duty_pct < 90
                                      ? C.danger
                                      : d.duty_pct < 100
                                      ? C.warning
                                      : C.success,
                                  fontWeight: 600,
                                }}
                              >
                                {d.duty_pct}%
                              </td>
                              <td style={{ padding: '4px 8px' }}>{d.Tout}°C</td>
                              <td
                                style={{
                                  padding: '4px 8px',
                                  color: d.clean_needed ? C.danger : C.success,
                                  fontWeight: 600,
                                }}
                              >
                                {d.clean_needed ? '⚠ CLEAN' : '✓ OK'}
                              </td>
                            </tr>
                          ))}
                      </tbody>
                    </table>
                    <div
                      style={{
                        marginTop: 8,
                        padding: '6px 8px',
                        background: C.accentLt,
                        borderRadius: 4,
                        fontSize: 9,
                        color: C.accent,
                      }}
                    >
                      <b>Recommended Cleaning Interval:</b>{' '}
                      {r.foulData.findIndex((d: any) => d.clean_needed) > 0
                        ? `Month ${r.foulData.findIndex(
                            (d: any) => d.clean_needed
                          )} — when duty drops below 90%`
                        : 'No cleaning required within 24 months — low fouling service'}
                    </div>
                  </div>
                </div>
              </>
            )}

            {r && rTab === 'flowstudy' && (
              <>
                <div style={{ padding: '10px 12px 4px' }}>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: C.text,
                      marginBottom: 2,
                    }}
                  >
                    Variable Flow — Off-Design Performance Study
                  </div>
                  <div
                    style={{ fontSize: 9, color: C.textDim, marginBottom: 8 }}
                  >
                    Performance at 30% to 150% of design flow rate. Identifies
                    operating envelope and constraint violations.
                  </div>
                </div>
                <div style={{ padding: '0 12px 12px' }}>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 14,
                      border: `1px solid ${C.border}`,
                      marginBottom: 12,
                    }}
                  >
                    <div
                      style={{ fontSize: 10, fontWeight: 700, marginBottom: 8 }}
                    >
                      Heat Duty & Velocities vs Flow Rate
                    </div>
                    <ResponsiveContainer width="100%" height={240}>
                      <LineChart
                        data={r.flowData}
                        margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={C.border}
                        />
                        <XAxis
                          dataKey="flow_pct"
                          label={{
                            value: 'Flow % of Design',
                            position: 'insideBottom',
                            offset: -3,
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          yAxisId="Q"
                          label={{
                            value: 'Duty (kW)',
                            angle: -90,
                            position: 'insideLeft',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          yAxisId="V"
                          orientation="right"
                          label={{
                            value: 'Velocity (m/s)',
                            angle: 90,
                            position: 'insideRight',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <Tooltip
                          contentStyle={{
                            fontSize: 10,
                            background: C.panel,
                            border: `1px solid ${C.border}`,
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: 9 }} />
                        <ReferenceLine
                          xAxisId={undefined}
                          x={100}
                          stroke={C.accent}
                          strokeDasharray="5 5"
                          label={{
                            value: 'Design',
                            fontSize: 8,
                            fill: C.accent,
                          }}
                        />
                        <Line
                          yAxisId="Q"
                          type="monotone"
                          dataKey="Q"
                          stroke={C.accent}
                          strokeWidth={2.5}
                          dot={false}
                          name="Heat Duty (kW)"
                        />
                        <Line
                          yAxisId="V"
                          type="monotone"
                          dataKey="vt"
                          stroke={C.success}
                          strokeWidth={1.5}
                          dot={false}
                          name="Tube Velocity (m/s)"
                        />
                        <Line
                          yAxisId="V"
                          type="monotone"
                          dataKey="vs"
                          stroke={C.warning}
                          strokeWidth={1.5}
                          dot={false}
                          strokeDasharray="4 2"
                          name="Shell Velocity (m/s)"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 14,
                      border: `1px solid ${C.border}`,
                      marginBottom: 12,
                    }}
                  >
                    <div
                      style={{ fontSize: 10, fontWeight: 700, marginBottom: 8 }}
                    >
                      Pressure Drop vs Flow Rate
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                      <LineChart
                        data={r.flowData}
                        margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={C.border}
                        />
                        <XAxis
                          dataKey="flow_pct"
                          label={{
                            value: 'Flow % of Design',
                            position: 'insideBottom',
                            offset: -3,
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <YAxis
                          label={{
                            value: 'ΔP (kPa)',
                            angle: -90,
                            position: 'insideLeft',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <Tooltip
                          contentStyle={{
                            fontSize: 10,
                            background: C.panel,
                            border: `1px solid ${C.border}`,
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: 9 }} />
                        <ReferenceLine
                          x={100}
                          stroke={C.accent}
                          strokeDasharray="5 5"
                        />
                        <ReferenceLine
                          y={100}
                          stroke={C.danger}
                          strokeDasharray="4 2"
                          label={{
                            value: 'Tube ΔP limit',
                            fontSize: 8,
                            fill: C.danger,
                          }}
                        />
                        <ReferenceLine
                          y={80}
                          stroke={C.warning}
                          strokeDasharray="4 2"
                          label={{
                            value: 'Shell ΔP limit',
                            fontSize: 8,
                            fill: C.warning,
                          }}
                        />
                        <Line
                          type="monotone"
                          dataKey="dPt"
                          stroke={C.success}
                          strokeWidth={2}
                          dot={false}
                          name="Tube ΔP (kPa)"
                        />
                        <Line
                          type="monotone"
                          dataKey="dPs"
                          stroke={C.warning}
                          strokeWidth={2}
                          dot={false}
                          name="Shell ΔP (kPa)"
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 12,
                      border: `1px solid ${C.border}`,
                    }}
                  >
                    <div
                      style={{ fontSize: 10, fontWeight: 700, marginBottom: 8 }}
                    >
                      Operating Envelope — Constraint Check
                    </div>
                    <table
                      style={{
                        width: '100%',
                        borderCollapse: 'collapse',
                        fontSize: 9,
                      }}
                    >
                      <thead>
                        <tr style={{ background: C.header }}>
                          {[
                            'Flow %',
                            'Flow kg/s',
                            'Tube V',
                            'Shell V',
                            'Tube ΔP',
                            'Shell ΔP',
                            'Status',
                          ].map((h) => (
                            <th
                              key={h}
                              style={{
                                padding: '4px 6px',
                                color: '#fff',
                                textAlign: 'center',
                                fontWeight: 600,
                              }}
                            >
                              {h}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {r.flowData
                          .filter((_: any, i: number) => i % 2 === 0)
                          .map((d: any, i: number) => {
                            const allOk =
                              d.ok_vt && d.ok_vs && d.ok_dPt && d.ok_dPs;
                            return (
                              <tr
                                key={i}
                                style={{
                                  background:
                                    d.flow_pct === 100
                                      ? C.accentLt
                                      : !allOk
                                      ? C.dangerLt
                                      : i % 2 === 0
                                      ? C.panel
                                      : C.panelAlt,
                                }}
                              >
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    fontWeight: d.flow_pct === 100 ? 700 : 400,
                                  }}
                                >
                                  {d.flow_pct}%
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                  }}
                                >
                                  {d.flow}
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    color: d.ok_vt ? C.success : C.danger,
                                  }}
                                >
                                  {d.vt}
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    color: d.ok_vs ? C.success : C.danger,
                                  }}
                                >
                                  {d.vs}
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    color: d.ok_dPt ? C.success : C.danger,
                                  }}
                                >
                                  {d.dPt}
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    color: d.ok_dPs ? C.success : C.danger,
                                  }}
                                >
                                  {d.dPs}
                                </td>
                                <td
                                  style={{
                                    padding: '3px 6px',
                                    textAlign: 'center',
                                    fontWeight: 700,
                                    color: allOk ? C.success : C.danger,
                                  }}
                                >
                                  {allOk ? '✓ OK' : '✗ FAIL'}
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}

            {r && rTab === 'shellcomp' && (
              <>
                <div style={{ padding: '10px 12px 4px' }}>
                  <div
                    style={{
                      fontSize: 11,
                      fontWeight: 700,
                      color: C.text,
                      marginBottom: 2,
                    }}
                  >
                    Shell Type Comparison
                  </div>
                  <div
                    style={{ fontSize: 9, color: C.textDim, marginBottom: 8 }}
                  >
                    Compares E, F, G shells for your duty. Same tube geometry
                    and fluid conditions throughout.
                  </div>
                </div>
                <div style={{ padding: '0 12px' }}>
                  <div
                    style={{
                      display: 'grid',
                      gridTemplateColumns: 'repeat(3,1fr)',
                      gap: 12,
                      marginBottom: 12,
                    }}
                  >
                    {r.shellComps.map((sc: any, i: number) => (
                      <div
                        key={i}
                        style={{
                          background: i === 0 ? C.accentLt : C.panel,
                          borderRadius: 8,
                          padding: 14,
                          border: `2px solid ${i === 0 ? C.accent : C.border}`,
                        }}
                      >
                        <div
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            color: i === 0 ? C.accent : C.text,
                            marginBottom: 8,
                          }}
                        >
                          {sc.name}
                          {i === 0 ? ' ← Current' : ''}
                        </div>
                        <div
                          style={{
                            fontSize: 10,
                            color: C.textMid,
                            lineHeight: 2.2,
                          }}
                        >
                          Ft Factor:{' '}
                          <b
                            style={{
                              color:
                                sc.Ft >= 0.85
                                  ? C.success
                                  : sc.Ft >= 0.75
                                  ? C.warning
                                  : C.danger,
                            }}
                          >
                            {sc.Ft}
                          </b>
                          <br />
                          Area: <b>{sc.A} m²</b>
                          <br />
                          Tube Count: <b>{sc.Nt}</b>
                          <br />
                          Est. Cost: <b>${sc.cost.toLocaleString()}</b>
                          <br />
                          Status:{' '}
                          <b
                            style={{
                              color: sc.Ft >= 0.75 ? C.success : C.danger,
                            }}
                          >
                            {sc.Ft >= 0.75 ? '✓ Acceptable' : '✗ FAIL'}
                          </b>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div
                    style={{
                      background: C.panel,
                      borderRadius: 8,
                      padding: 14,
                      border: `1px solid ${C.border}`,
                    }}
                  >
                    <div
                      style={{ fontSize: 10, fontWeight: 700, marginBottom: 8 }}
                    >
                      Area & Cost Comparison
                    </div>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart
                        data={r.shellComps}
                        margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
                      >
                        <CartesianGrid
                          strokeDasharray="3 3"
                          stroke={C.border}
                        />
                        <XAxis dataKey="name" tick={{ fontSize: 9 }} />
                        <YAxis
                          yAxisId="area"
                          label={{
                            value: 'Area (m²)',
                            angle: -90,
                            position: 'insideLeft',
                            fontSize: 9,
                          }}
                          tick={{ fontSize: 9 }}
                        />
                        <Tooltip
                          contentStyle={{
                            fontSize: 10,
                            background: C.panel,
                            border: `1px solid ${C.border}`,
                          }}
                        />
                        <Legend wrapperStyle={{ fontSize: 9 }} />
                        <Bar
                          yAxisId="area"
                          dataKey="A"
                          fill={C.accent}
                          name="Area (m²)"
                          radius={[4, 4, 0, 0]}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                  <div
                    style={{
                      marginTop: 10,
                      padding: 10,
                      background: C.purpleLt,
                      borderRadius: 6,
                      border: `1px solid ${C.purple}`,
                      fontSize: 9,
                      color: C.purple,
                      lineHeight: 1.8,
                    }}
                  >
                    <b>Recommendation:</b> For your R={r.R} and S={r.S},{' '}
                    {parseFloat(r.Ft) >= 0.85
                      ? `E-shell is optimal (Ft=${r.Ft}). No need for F or G shell.`
                      : `E-shell Ft=${r.Ft} is marginal. Consider F-shell which gives higher Ft and smaller area.`}
                  </div>
                </div>
              </>
            )}

            {r && rTab === 'checks' && (
              <>
                <SH t="Thermal Checks" c={C.warning} />
                <RW
                  k="Ft Factor ≥ 0.75"
                  v={
                    parseFloat(r.Ft) >= 0.75
                      ? 'PASS ✓'
                      : 'FAIL ✗ — Add passes/change shell'
                  }
                  hi={parseFloat(r.Ft) >= 0.75}
                  warn={parseFloat(r.Ft) < 0.75}
                />
                <RW
                  k="Overdesign 10–35%"
                  v={
                    parseFloat(r.overdesign_actual) >= 10 &&
                    parseFloat(r.overdesign_actual) <= 35
                      ? 'PASS ✓'
                      : `WARN ⚠ (${r.overdesign_actual}%)`
                  }
                  hi={
                    parseFloat(r.overdesign_actual) >= 10 &&
                    parseFloat(r.overdesign_actual) <= 35
                  }
                  warn={parseFloat(r.overdesign_actual) > 40}
                />
                <RW
                  k="Effectiveness ≥ 60%"
                  v={parseFloat(r.eff) >= 60 ? 'PASS ✓' : 'WARN ⚠'}
                  hi={parseFloat(r.eff) >= 60}
                  warn={parseFloat(r.eff) < 60}
                />
                <SH t="Hydraulic Checks" c={C.warning} />
                <RW
                  k="Tube Velocity (0.5–3.0 m/s)"
                  v={!r.warn_vt ? 'PASS ✓' : 'FAIL ✗'}
                  hi={!r.warn_vt}
                  warn={r.warn_vt}
                />
                <RW
                  k="Shell Velocity (0.3–1.5 m/s)"
                  v={!r.warn_vs ? 'PASS ✓' : 'WARN ⚠'}
                  hi={!r.warn_vs}
                  warn={r.warn_vs}
                />
                <RW
                  k="Tube ΔP ≤ 100 kPa"
                  v={!r.warn_dPt ? 'PASS ✓' : 'FAIL ✗'}
                  hi={!r.warn_dPt}
                  warn={r.warn_dPt}
                />
                <RW
                  k="Shell ΔP ≤ 80 kPa"
                  v={!r.warn_dPs ? 'PASS ✓' : 'FAIL ✗'}
                  hi={!r.warn_dPs}
                  warn={r.warn_dPs}
                />
                <RW
                  k="Shell Nozzle ρV² (TEMA)"
                  v={
                    !r.warn_rv2_h ? 'PASS ✓' : 'FAIL ✗ — Add impingement plate'
                  }
                  hi={!r.warn_rv2_h}
                  warn={r.warn_rv2_h}
                />
                <SH t="Mechanical Checks" c={C.warning} />
                <RW
                  k="Material Temp Limit"
                  v={
                    !r.warn_matT
                      ? 'PASS ✓'
                      : `FAIL ✗ — Exceeds ${MATERIALS[matTube].max_T}°C`
                  }
                  hi={!r.warn_matT}
                  warn={r.warn_matT}
                />
                <RW
                  k="Thermal Expansion Joint"
                  v={r.exp_req}
                  hi={r.exp_req === 'NO'}
                  warn={r.exp_req.includes('YES')}
                />
                <RW
                  k="Tube Vibration Risk"
                  v={r.vib}
                  hi={r.vib.includes('LOW')}
                  warn={r.vib.includes('HIGH')}
                />
                <SH t="Client Constraint Checks" c={C.purple} />
                {constraintResults.length > 0 ? (
                  constraintResults.map((c: any, i: number) => (
                    <RW
                      key={i}
                      k={c.name}
                      v={
                        c.ok
                          ? 'PASS ✓'
                          : `FAIL ✗ — ${c.val} vs limit ${c.limit}`
                      }
                      hi={c.ok}
                      warn={!c.ok}
                    />
                  ))
                ) : (
                  <RW k="No constraints set" v="Add limits in LIMITS tab" />
                )}
              </>
            )}

            {r && rTab === 'datasheet' && (
              <div style={{ padding: 14 }} id="hx-printable">
                <button
                  className="no-print"
                  onClick={() => window.print()}
                  style={{
                    background: C.accent,
                    border: 'none',
                    color: '#fff',
                    padding: '9px 22px',
                    borderRadius: 4,
                    fontSize: 11,
                    fontFamily: 'inherit',
                    fontWeight: 700,
                    cursor: 'pointer',
                    marginBottom: 14,
                    letterSpacing: 1,
                  }}
                >
                  ⬇ EXPORT PDF — DATASHEET
                </button>
                <div
                  style={{
                    border: `1px solid ${C.borderStrong}`,
                    borderRadius: 6,
                    overflow: 'hidden',
                    background: '#fff',
                    boxShadow: '0 2px 8px rgba(0,0,0,0.08)',
                  }}
                >
                  <div
                    style={{
                      background: C.header,
                      padding: '14px 18px',
                      display: 'flex',
                      justifyContent: 'space-between',
                    }}
                  >
                    <div>
                      <div
                        style={{
                          fontSize: 16,
                          color: '#fff',
                          fontWeight: 700,
                          letterSpacing: 1,
                        }}
                      >
                        EQUIPMENT DATASHEET
                      </div>
                      <div
                        style={{ fontSize: 9, color: '#90a4ae', marginTop: 2 }}
                      >
                        SHELL & TUBE HEAT EXCHANGER — TEMA {r.temaDesig}
                      </div>
                      <div
                        style={{ fontSize: 8, color: '#607d8b', marginTop: 1 }}
                      >
                        ASME SEC.VIII DIV.1 · TEMA{' '}
                        {temaClass.split('—')[0].trim()} CLASS
                        {api660 === 'Yes' ? ' · API 660' : ''}
                        {uStamp === 'Yes' ? ' · ASME U-STAMP' : ''}
                      </div>
                    </div>
                    <div
                      style={{
                        textAlign: 'right',
                        fontSize: 10,
                        color: '#90a4ae',
                        lineHeight: 2.1,
                      }}
                    >
                      <div>
                        Project: <b style={{ color: '#fff' }}>{projName}</b>
                      </div>
                      <div>
                        Location: <b style={{ color: '#fff' }}>{plantLoc}</b>
                      </div>
                      <div>
                        Client: <b style={{ color: '#fff' }}>{client}</b>
                      </div>
                      <div>
                        Doc No: <b style={{ color: '#64b5f6' }}>{docNo}</b>
                      </div>
                      <div>
                        Rev: <b style={{ color: '#ffd54f' }}>{revNo}</b> —{' '}
                        {revDesc}
                      </div>
                    </div>
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      borderBottom: `1px solid ${C.border}`,
                    }}
                  >
                    {[
                      ['Prepared By', prepBy],
                      ['Checked By', chkBy],
                      ['Approved By', appBy],
                    ].map(([role, name]) => (
                      <div
                        key={role}
                        style={{
                          flex: 1,
                          padding: '7px 14px',
                          borderRight: `1px solid ${C.border}`,
                        }}
                      >
                        <div
                          style={{
                            fontSize: 8,
                            color: C.textDim,
                            letterSpacing: 1,
                          }}
                        >
                          {(role as string).toUpperCase()}
                        </div>
                        <div
                          style={{
                            fontSize: 10,
                            color: C.text,
                            fontWeight: 600,
                            marginTop: 2,
                          }}
                        >
                          {name}
                        </div>
                        <div style={{ fontSize: 8, color: C.textDim }}>
                          {new Date().toLocaleDateString()}
                        </div>
                      </div>
                    ))}
                  </div>
                  {(
                    [
                      [
                        '1. GENERAL',
                        [
                          [
                            'Equipment Tag',
                            eqTag,
                            'TEMA Class',
                            temaClass.split('—')[0].trim(),
                          ],
                          [
                            'Service',
                            `${useCustomH ? 'Custom' : hFluid} / ${
                              useCustomC ? 'Custom' : cFluid
                            }`,
                            'TEMA Designation',
                            r.temaDesig,
                          ],
                          [
                            'Shell Type',
                            shellType.split('—')[1]?.trim() || shellType,
                            'Bundle Type',
                            bundleType.split('—')[1]?.trim() || bundleType,
                          ],
                          [
                            'Front Head',
                            frontHead.split('—')[1]?.trim() || frontHead,
                            'Tube Passes',
                            tubePasses,
                          ],
                          ['Orientation', orientation, 'ASME U-Stamp', uStamp],
                          ['API 660', api660, 'Nameplate', nameplate],
                          ['Paint', paintSpec, 'Shipping', shipCond],
                          [
                            'Insulation',
                            insulReq === 'Yes' ? `Yes — ${insulThk}mm` : 'No',
                            'Saddle Supports',
                            numSaddles,
                          ],
                        ],
                      ],
                      [
                        '2. PROCESS CONDITIONS',
                        [
                          ['', 'SHELL SIDE (HOT)', '', 'TUBE SIDE (COLD)', ''],
                          ['', 'NORMAL', 'DESIGN', 'NORMAL', 'DESIGN'],
                          [
                            'Fluid',
                            useCustomH ? 'Custom Fluid' : hFluid,
                            '',
                            useCustomC ? 'Custom Fluid' : cFluid,
                            '',
                          ],
                          [
                            'Temp In/Out (°C)',
                            `${hTin}/${hTout}`,
                            hDesT,
                            `${cTin}/${cTout}`,
                            cDesT,
                          ],
                          ['Pressure (bar g)', hOpP, hDesP, cOpP, cDesP],
                          ['Flow (kg/s)', hFlow, '—', r.mc, '—'],
                          [
                            'Fouling (m²K/W)',
                            FOULING[hFoul] || 0.0006,
                            '',
                            FOULING[cFoul] || 0.0004,
                            '',
                          ],
                          [
                            'Test Pressure (bar g)',
                            r.P_test_sh,
                            '',
                            r.P_test_tu,
                            '',
                          ],
                        ],
                      ],
                      [
                        '2a. OPERATING CASES',
                        [
                          ['Case', 'Shell P (bar g)', 'Shell T (°C)', 'Notes'],
                          ['Normal', hOpP, hOpT, 'Design basis'],
                          ['Start-Up', hPstart, hTstart, 'Max during startup'],
                          ['Upset', hPupset, hTupset, 'Relief valve basis'],
                          [
                            'Steamout',
                            hSteamP,
                            hSteamT,
                            'Maintenance cleaning',
                          ],
                        ],
                      ],
                      [
                        '3. THERMAL PERFORMANCE',
                        [
                          [
                            'Heat Duty',
                            `${r.Q} kW (${r.Q_MW} MW)`,
                            'Effectiveness',
                            `${r.eff}%`,
                          ],
                          [
                            'LMTD Corrected',
                            `${r.eff_lmtd}°C (Ft=${r.Ft})`,
                            'NTU',
                            r.NTU,
                          ],
                          [
                            'U Clean / Dirty',
                            `${r.U_cl} / ${r.U_dir} W/m²·K`,
                            'Overdesign',
                            `${r.overdesign_actual}%`,
                          ],
                          [
                            'Area Required / Actual',
                            `${r.A_req} / ${r.A_actual} m²`,
                            'Shells',
                            r.shells,
                          ],
                        ],
                      ],
                      [
                        '4. TUBE COUNT (STEP-BY-STEP)',
                        [
                          [
                            'Area per Tube',
                            `${r.A_per_tube} m²`,
                            'Calculated Nt',
                            `${r.Nt_calc} (before rounding)`,
                          ],
                          [
                            'Total Tubes (Nt)',
                            `${r.Nt}`,
                            'Tubes per Pass',
                            `${r.Ntp}`,
                          ],
                          [
                            'Tube OD / ID / Wall',
                            `${r.OD_mm} / ${r.ID_mm} / ${tubeThk} mm`,
                            'Tube Length',
                            `${r.L} m`,
                          ],
                          [
                            'Pitch / Layout',
                            pitchK,
                            'Tube-TS Joint',
                            tubeTSJoint,
                          ],
                        ],
                      ],
                      [
                        '5. MECHANICAL DESIGN',
                        [
                          [
                            'Shell Material',
                            matShell,
                            'Shell ID',
                            `${r.Ds_mm} mm`,
                          ],
                          [
                            'Tube Material',
                            matTube,
                            'Shell Wall (ASME)',
                            `${r.t_sh} mm`,
                          ],
                          [
                            'Baffle Spacing/Cut',
                            `${baffleSpacing}mm / ${baffleCut}%`,
                            'No. of Baffles',
                            r.Nb,
                          ],
                          ['Gasket', matGasket, 'Fasteners', matFastener],
                          [
                            'Joint Efficiency',
                            r.E,
                            'Corrosion Allowance',
                            `${r.ca} mm`,
                          ],
                        ],
                      ],
                      [
                        '6. NOZZLE SCHEDULE',
                        [
                          [
                            'Tag',
                            'Service',
                            'Size',
                            'Sch',
                            'Flange',
                            'P&ID Line',
                            'Qty',
                          ],
                          [
                            'N1',
                            'Shell Inlet',
                            hInN,
                            hInSch,
                            flangeClass,
                            hInLine,
                            '1',
                          ],
                          [
                            'N2',
                            'Shell Outlet',
                            hOutN,
                            hOutSch,
                            flangeClass,
                            hOutLine,
                            '1',
                          ],
                          [
                            'N3',
                            'Tube Inlet',
                            cInN,
                            cInSch,
                            flangeClass,
                            cInLine,
                            '1',
                          ],
                          [
                            'N4',
                            'Tube Outlet',
                            cOutN,
                            cOutSch,
                            flangeClass,
                            cOutLine,
                            '1',
                          ],
                          ['N5', 'Vent', ventN, 'Sch 80', '150#', '—', '2'],
                          ['N6', 'Drain', drainN, 'Sch 80', '150#', '—', '2'],
                        ],
                      ],
                      [
                        '7. WEIGHTS & COST',
                        [
                          [
                            'Empty Weight',
                            `${r.W_empty.toLocaleString()} kg`,
                            'Operating Weight',
                            `${r.W_oper.toLocaleString()} kg`,
                          ],
                          [
                            'Hydrotest Weight',
                            `${r.W_hydro.toLocaleString()} kg`,
                            'Estimated Cost',
                            `USD ${r.cost}`,
                          ],
                        ],
                      ],
                      [
                        '8. DESIGN CHECKS',
                        [
                          [
                            'Ft Factor',
                            parseFloat(r.Ft) >= 0.75 ? 'PASS ✓' : 'FAIL ✗',
                            'Tube ΔP',
                            !r.warn_dPt ? 'PASS ✓' : 'FAIL ✗',
                          ],
                          [
                            'Tube Velocity',
                            !r.warn_vt ? 'PASS ✓' : 'FAIL ✗',
                            'Shell ΔP',
                            !r.warn_dPs ? 'PASS ✓' : 'FAIL ✗',
                          ],
                          [
                            'Shell Nozzle ρV²',
                            !r.warn_rv2_h ? 'PASS ✓' : 'FAIL ✗',
                            'Vibration',
                            r.vib,
                          ],
                          [
                            'Thermal Expansion',
                            r.exp_req,
                            'Material Temp',
                            !r.warn_matT ? 'PASS ✓' : 'FAIL ✗',
                          ],
                          [
                            'HX Type Recommended',
                            hxRecs[0]?.name || '—',
                            '',
                            '',
                          ],
                        ],
                      ],
                    ] as any[]
                  ).map(([sec, rows]: any) => (
                    <div key={sec}>
                      <div
                        style={{
                          background: C.header,
                          padding: '4px 14px',
                          fontSize: 9,
                          color: '#64b5f6',
                          fontWeight: 700,
                          letterSpacing: 1,
                        }}
                      >
                        {sec}
                      </div>
                      {rows.map((row: any, i: number) => (
                        <div
                          key={i}
                          style={{
                            display: 'flex',
                            borderBottom: `1px solid ${C.border}`,
                            background: i % 2 === 0 ? '#fff' : C.panelAlt,
                          }}
                        >
                          {row.map((cell: any, j: number) => (
                            <span
                              key={j}
                              style={{
                                flex: 1,
                                padding: '4px 14px',
                                fontSize: 9,
                                color: j % 2 === 0 ? C.textDim : C.text,
                                fontWeight: j % 2 !== 0 ? 600 : 400,
                              }}
                            >
                              {cell}
                            </span>
                          ))}
                        </div>
                      ))}
                    </div>
                  ))}
                  <div
                    style={{
                      padding: '8px 14px',
                      background: C.panelAlt,
                      fontSize: 8,
                      color: C.textDim,
                      lineHeight: 1.8,
                      borderTop: `1px solid ${C.border}`,
                    }}
                  >
                    GENERATED BY HX-CALC EPC | KERN METHOD + BELL-DELAWARE |
                    ASME SECTION VIII DIVISION 1 | TEMA{' '}
                    {temaClass.split('—')[0].trim()} CLASS
                    {api660 === 'Yes' ? ' | API 660' : ''} | PRELIMINARY DESIGN
                    — DETAILED ENGINEERING + VENDOR REVIEW REQUIRED | ©{' '}
                    {new Date().getFullYear()} {prepBy}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
